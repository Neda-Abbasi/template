$('#service').change(function() {
    var cost = parseFloat($(this).find(':selected').data('cost'));
    var qty = parseInt($("#qty").val());
    $("#cost").val(cost);
    $("#total").val(cost * qty);
});
$('#product').change(function() {
    var available = parseFloat($(this).find(':selected').data('available'));
    var sell = parseFloat($(this).find(':selected').data('sell'));
    var purchase = parseFloat($(this).find(':selected').data('purchase'));
    var qty = parseInt($("#p_qty").val());
    $("#available").val(available);
    $("#p_cost").val(sell);
    $("#purchase").val(purchase);
    $("#p_total").val(sell * qty);
});
$('#qty').keyup(function() {
    var cost = parseFloat($("#cost").val());
    var qty = parseInt($("#qty").val());
    $("#total").val(cost * qty);
});
$('#p_qty').keyup(function() {
    var p_cost = parseFloat($("#p_cost").val());
    var p_qty = parseInt($("#p_qty").val());
    $("#p_total").val(p_cost * p_qty);
});


$('.jsAddGood').click(function() {
    var isSame = true;
    if (isSame) {
        var str = "";
        var staff = $("#staff :selected").text();
        var staff_id = $("#staff :selected").val();
        var service = $("#service :selected").text();
        var service_id = $("#service :selected").val();
        var qty = $("#qty").val();
        var cost = $("#cost").val();


        if (!staff_id || !qty || !cost) {
            if (!staff_id) {
                alert("کارمند را انتخاب نمایید");
            } else if (!qty) {
                alert("تعداد را وارد نمایید");
            } else {
                alert("قیمت را وارد نمایید");
            }
            return false;
        }

        var count = $(".jsGoodsTable tbody tr").length;
        count++;
        str += '<tr><td>' + service + '</td>';
        str += '<td class="d-none ServiceId">' + service_id + '</td>';
        str += '<td>' + staff + '</td>';
        str += '<td class="d-none StaffId">' + staff_id + '</td>';
        str += '<td class="Qty">' + qty + '</td>';
        str += '<td class="Cost">' + cost + '</td>';
        str += '<td class="Total">' + parseFloat(qty) * parseFloat(cost) + '</td>';
        str += '<td><input type="button" class="btn btn-sm btn-danger jsDelete" id="jsDelete"  onclick="Rowdelete(this)" value="X" /></td></tr>';
        $(".jsGoodsTable tbody").append(str);
        var gtc = parseFloat($("#grand_total").val());
        isNaN(gtc) ? gtc = 0 : gtc = gtc;
        
        var total_cost = $("#total").val();
        isNaN(total_cost) ? total_cost = 0 : total_cost = total_cost;
        $("#grand_total").val(parseFloat(gtc) + parseFloat(total_cost));
        $("#payable").val(parseFloat(gtc) + parseFloat(total_cost));
        var gt = parseFloat($("#grand_total").val());
        
        var dis = $("#discount").val();
        isNaN(dis) ? dis = 0 : dis = dis;
        var ba = parseFloat(gt) - parseFloat(dis);
        $("#payable").val(ba);
        clearControls();
    }
});


$('.jsAddProduct').click(function() {
    var isSame = true;
    if (isSame) {
        var str = "";
        var product = $("#product :selected").text();
        var product_id = $("#product :selected").val();
        var available = $("#available").val();
        var purchase = $("#purchase").val();
        var p_qty = $("#p_qty").val();
        var p_cost = $("#p_cost").val();


        if (!product_id || !p_qty || !p_cost) {
            if (!product_id) {
                alert("محصول را انتخاب نمایید");
            } else if (!qty) {
                alert("تعداد را وارد نمایید");
            } else {
                alert("قیمت را وارد نمایید");
            }
            return false;
        }

        var count = $(".jsProductsTable tbody tr").length;
        count++;
        str += '<tr><td>' + product + '</td>';
        str += '<td class="d-none product_id">' + product_id + '</td>';
        str += '<td class="d-none purchase">' + purchase + '</td>';
        str += '<td class="available">' + available + '</td>';
        str += '<td class="p_qty">' + p_qty + '</td>';
        str += '<td class="p_cost">' + p_cost + '</td>';
        str += '<td class="p_total">' + parseFloat(p_qty) * parseFloat(p_cost) + '</td>';
        str += '<td><input type="button" class="btn btn-sm btn-danger jsPDelete" id="jsPDelete"  onclick="RowPdelete(this)" value="X" /></td></tr>';
        $(".jsProductsTable tbody").append(str);
        var gtc = parseFloat($("#grand_total").val());
        isNaN(gtc) ? gtc = 0 : gtc = gtc;
        
        var p_total_cost = $("#p_total").val();
        isNaN(p_total_cost) ? p_total_cost = 0 : p_total_cost = p_total_cost;
        $("#grand_total").val(parseFloat(gtc) + parseFloat(p_total_cost));
        $("#payable").val(parseFloat(gtc) + parseFloat(p_total_cost));
        var gt = parseFloat($("#grand_total").val());
        
        var dis = $("#discount").val();
        isNaN(dis) ? dis = 0 : dis = dis;
        var ba = parseFloat(gt) - parseFloat(dis);
        $("#payable").val(ba);
        clearPControls();
    }
});


$('#discount').keyup(function() {
    var a = 0;
    var b = 0;
    a = parseFloat($('#grand_total').val());
    b = parseFloat($('#discount').val());
    isNaN(a) ? a = 0 : a = a;
    isNaN(b) ? b = 0 : b = b;
    $('#payable').val(a - b);
});

function clearControls() {
    $("#qty").val(1);
    // $("#cost").val(0);
    // $("#total").val(0);
}
function clearPControls() {
    $("#p_qty").val(1);
    // $("#p_cost").val(0);
    // $("#p_total").val(0);
    // $("#available").val(0);
    // $("#cost").val(0);
    // $("#total").val(0);
}

function getData() {
    var goods_list = [];
    $(".jsGoodsTable tbody tr").each(function() {
        var el = $(this);
        var good = {};
        good.service_id = el.find(".ServiceId").html().trim();
        good.staff_id = el.find(".StaffId").html().trim();
        good.Qty = el.find(".Qty").html().trim();
        good.Cost = el.find(".Cost").html().trim();
        good.total = el.find(".Total").html().trim();
        goods_list.push(good);
        //console.log(goods_list);
    });
    var jsonString = JSON.stringify(goods_list);
    $("#hfGoodList").val(jsonString);

    var products_list = [];
    $(".jsProductsTable tbody tr").each(function() {
        var el = $(this);
        var product = {};
        product.product_id = el.find(".product_id").html().trim();
        product.purchase = el.find(".purchase").html().trim();
        product.p_qty = el.find(".p_qty").html().trim();
        product.p_cost = el.find(".p_cost").html().trim();
        // product.p_total = el.find(".p_total").html().trim();
        products_list.push(product);
        //console.log(products_list);
    });
    var jsonString = JSON.stringify(products_list);
    $("#hfProductList").val(jsonString);
    // return confirm('آیا مطمین هستید ثبت شود؟');
}

function Rowdelete(el) {
    var el = $(el).parents('tr');
    var cost = el.find('.Cost').html();
    var qty = el.find('.Qty').html();
    var amount = parseFloat(cost) * parseFloat(qty);
    var totalCost = parseFloat($("#grand_total").val());
    totalCost = totalCost - amount;
    $("#grand_total").val(totalCost);
    $("#payable").val(totalCost);

    //	$(el).parents('tr').remove();
    $(el).closest('tr').remove();
}
function RowPdelete(el) {
    var el = $(el).parents('tr');
    var cost = el.find('.p_cost').html();
    var qty = el.find('.p_qty').html();
    var amount = parseFloat(cost) * parseFloat(qty);
    var totalCost = parseFloat($("#grand_total").val());
    totalCost = totalCost - amount;
    $("#grand_total").val(totalCost);
    $("#payable").val(totalCost);
    //	$(el).parents('tr').remove();
    $(el).closest('tr').remove();
}