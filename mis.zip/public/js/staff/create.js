$('.services').addClass('d-none');
$('#type').change(function() {
    var type = $(this).val();
    if(type =='percentage'){
        $('#salary').attr('readonly', 'readonly');
        $('.services').removeClass('d-none');
    }else{
        $('.services').addClass('d-none');
        $('#salary').removeAttr('readonly');
    }

   
});