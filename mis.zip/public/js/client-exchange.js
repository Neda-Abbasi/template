
$('#from').change(function() {
    var from_currency_name = $('#from').find(':selected').data('currency');
    var to_currency_name = $('#to').find(':selected').data('currency');
    $("#from_currency_name").val(from_currency_name);
    $("#to_currency_name").val(to_currency_name);

    var old_balance = parseFloat($('#from').find(':selected').data('balance'));
    $("#available").val(old_balance);
    $('.label_rate_from').text('نرخ تبادله '+from_currency_name);
    $('.label_rate_to').text('نرخ تبادله '+to_currency_name);

    var amount = parseFloat($("#amount").val());
    var rate_from = parseFloat($("#rate_from").val());
    var rate_to = parseFloat($("#rate_to").val());

    var total = 0;
    if(old_balance < amount){
        alert('بلانس کافی موجود نیست');
        $("#amount").val();
    }else{
        if(!isNaN(rate_from) && rate_from > 0){
            total = amount * rate_from;
        }else if(!isNaN(rate_to) && rate_to > 0){
            total = amount * rate_to;
        }
    }

    $("#total").val(total);

});

$('#to').change(function() {
    var from_currency_name = $('#from').find(':selected').data('currency');
    var to_currency_name = $('#to').find(':selected').data('currency');
    $("#from_currency_name").val(from_currency_name);
    $("#to_currency_name").val(to_currency_name);

    var old_balance = parseFloat($('#from').find(':selected').data('balance'));
    $("#available").val(old_balance);
    $('.label_rate_from').text('نرخ تبادله '+from_currency_name);
    $('.label_rate_to').text('نرخ تبادله '+to_currency_name);

    var amount = parseFloat($("#amount").val());
    var rate_from = parseFloat($("#rate_from").val());
    var rate_to = parseFloat($("#rate_to").val());

    var total = 0;
    if(old_balance < amount){
        alert('بلانس کافی موجود نیست');
        $("#amount").val();
    }else{
        if(!isNaN(rate_from) && rate_from > 0){
            total = amount * rate_from;
        }else if(!isNaN(rate_to) && rate_to > 0){
            total = amount * rate_to;
        }
    }

    $("#total").val(total);



});
$('#amount, #rate_from').keyup(function() {
    var from_currency_name = $('#from').find(':selected').data('currency');
    var to_currency_name = $('#to').find(':selected').data('currency');
    $("#from_currency_name").val(from_currency_name);
    $("#to_currency_name").val(to_currency_name);

    var old_balance = parseFloat($('#from').find(':selected').data('balance'));
    $("#available").val(old_balance);
    $('.label_rate_from').text(from_currency_name + ' -> ' + to_currency_name);
    $('.label_rate_to').text(to_currency_name + ' -> ' + from_currency_name);

    var amount = parseFloat($("#amount").val());
    var rate_from = parseFloat($("#rate_from").val());
    var rate_to = parseFloat($("#rate_to").val());

    var total = 0;
    if(old_balance < amount){
        alert('بلانس کافی موجود نیست');
        $("#amount").val();
    }else{
        console.log('else called');
        if( rate_from > 0){
            total = amount * rate_from;
            var a =1/rate_from;
            $("#rate_to").val(a.toFixed(4));
            console.log('rate_from');
        }else if( rate_to > 0){
            console.log('rate_to');
            console.log('rate_to' + rate_to);
            console.log('amount' + amount);
            total = amount / rate_to;
            console.log('total' + total);
            var b =1/rate_from;
            
            console.log('rate_from' + rate_from);
            $("#rate_from").val(b.toFixed(4));
        }
    }

    $("#total").val(total.toFixed(4));




});