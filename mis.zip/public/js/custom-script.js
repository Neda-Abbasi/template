// $(document).ready(function() {
//     $('#date, #transaction_date').val(new Date().toDateInputValue());
// });​


$(document).ready(function() {
    $('.select2').select2();

    $('#datatable-report').DataTable( {
        paging: false,
        ordering: false,
        info: true,
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    });
    $('#datatable').DataTable( {
        lengthMenu: [
            [10, 25, 50, -1],
            [10, 25, 50, 'All'],
        ],
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    });

});
