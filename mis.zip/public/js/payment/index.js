$('#staff').change(function() {
    var fathername = $(this).find(':selected').data('fathername');
    var percentage = $(this).find(':selected').data('percentage');
    $("#fathername").val(fathername);
    $("#percentage").val(percentage);
});

$(document).ready(function(){
    var fathername = $('#staff').find(':selected').data('fathername');
    var percentage = $('#staff').find(':selected').data('percentage');
    $("#fathername").val(fathername);
    $("#percentage").val(percentage);
});