<?php

use App\Http\Controllers\BillController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ExpenseCategoryController;
use App\Http\Controllers\ExpenseController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\LogoutController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\StaffController;
use App\Http\Controllers\StaffPaymentController;
use App\Http\Controllers\StaffPercentageController;
use App\Http\Controllers\QueueNumberController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['middleware'=>['auth']], function(){

    Route::get('/logout', [LogoutController::class, 'logout'])->name('logout');
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard.index');
    
    
    Route::get('/staff/{staff}/service', [StaffController::class, 'getService'])->name('staff.service.get');
    Route::post('/staff/{staff_percentage}/service', [StaffController::class, 'postService'])->name('staff.service.post');
    Route::resource('/staff', StaffController::class);
    Route::post('/payment/staff', [StaffPaymentController::class, 'getPayment'])->name('payment.getPayment');
    
    Route::resource('/percentage', StaffPercentageController::class);
    Route::resource('/payment', StaffPaymentController::class);
    Route::resource('/service', ServiceController::class);
    Route::resource('/expense', ExpenseController::class);
    Route::resource('/bill', BillController::class);
    Route::resource('/category', ExpenseCategoryController::class);  
    Route::resource('/profile', ProfileController::class);
    Route::resource('/product', ProductController::class);
    Route::resource('/queue_number', QueueNumberController::class);
    Route::post('/queue/queue-filter', [QueueNumberController::class, 'FilterQueue'])->name('queue.FilterQueue');

    Route::get('/backup', function(){
        return view('backup');
    })->name('backup');


    //REPORTS
    Route::get('/report/discount', [ReportController::class, 'discountReport'])->name('report.discount');
    Route::post('/report/discount', [ReportController::class, 'getDiscountReport'])->name('report.getDiscount');
    
    Route::get('/report/expense', [ReportController::class, 'expenseReport'])->name('report.expense');
    Route::get('/report/expense-category', [ReportController::class, 'expenseCategoryReport'])->name('report.expense_category');
    Route::post('/report/expense', [ReportController::class, 'getExpenseReport'])->name('report.getExpense');
    Route::post('/report/expense-category', [ReportController::class, 'getExpenseCategoryReport'])->name('report.getExpenseCategory');

    Route::get('/report/income', [ReportController::class, 'incomeReport'])->name('report.income');
    Route::post('/report/income', [ReportController::class, 'getIncomeReport'])->name('report.getIncome');

    Route::get('/report/staff', [ReportController::class, 'staffReport'])->name('report.staff');
    Route::post('/report/staff', [ReportController::class, 'getStaffReport'])->name('report.getStaff');
    
    Route::get('/report/pl', [ReportController::class, 'PLReport'])->name('report.pl');
    Route::post('/report/pl', [ReportController::class, 'getPLReport'])->name('report.getpl');

    Route::get('/report/sell', [ReportController::class, 'sellReport'])->name('report.sell');
    Route::post('/report/sell', [ReportController::class, 'getSellReport'])->name('report.getSell');
});

Route::middleware(['guest'])->group(function(){
    Route::get('/login', [LoginController::class, 'index'])->name('login');
    Route::post('/login', [LoginController::class, 'store'])->name('login');

});

// $2y$10$um26d/X1bU6X7u7tmEn5MOPHIf.dSE3wvWdPR8c7HsZg0TGHFqA2. admin