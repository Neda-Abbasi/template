<?php

namespace App\Http\Controllers;

use App\Models\Bill;
use App\Models\BillDetail;
use App\Models\BillProduct;
use App\Models\Expense;
use App\Models\ExpenseCategory;
use App\Models\Service;
use App\Models\Staff;
use App\Models\StaffPayment;
use App\Models\StaffPercentage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    public function expenseReport(){
        return view('report.expense')->with('categories', ExpenseCategory::all());
    }
    public function expenseCategoryReport(){
        return view('report.expense_category')->with('categories', ExpenseCategory::all());
    }

    public function getExpenseReport(Request $request){
        $from = isset($request->from) ? $request->from : date("Y-m-d");
        $to = isset($request->to) ? $request->to : date("Y-m-d");

        $to = $to. ' 23:59:59';
        $from = $from. ' 00:00:00';
        
        if($request->category == 'all'){
            $logs = Expense::whereBetween('created_at', [$from, $to])->get();
        }else{
            $logs = Expense::whereBetween('created_at', [$from, $to])->where('expense_category_id', $request->category)->get();
        }
        return view('report.expense')->with('logs', $logs)->with('categories', ExpenseCategory::all());
    }
    public function getExpenseCategoryReport(Request $request){
        $from = isset($request->from) ? $request->from : date("Y-m-d");
        $to = isset($request->to) ? $request->to : date("Y-m-d");
        $to = $to. ' 23:59:59';
        $from = $from. ' 00:00:00';
        
        if($request->category == 'all'){
            $total = Expense::with('expense_category')->whereBetween('expense_date', [$from, $to])
                ->groupBy('expense_category_id')
                ->selectRaw('sum(amount) as sum, expense_category_id')
                ->whereBetween('created_at', [$from, $to])
                ->get('sum','expense_category_id');
        }else{
            
            $total = Expense::with('expense_category')->whereBetween('expense_date', [$from, $to])
                ->where('expense_category_id', $request->category)
                ->groupBy('expense_category_id')
                ->selectRaw('sum(amount) as sum, expense_category_id')
                ->get('sum','expense_category_id');
        }
        // dd($total);
        return view('report.expense_category')->with('total', $total)->with('categories', ExpenseCategory::all());
    }


    public function staffReport(){
        return view('report.staff')->with('staffs', Staff::where('status',1)->get());
    }

    public function getStaffReport(Request $request){
        $from = isset($request->from) ? $request->from : date("Y-m-d");
        $to = isset($request->to) ? $request->to : date("Y-m-d");

        $to = $to. ' 23:59:59';
        $from = $from. ' 00:00:00';
        if($request->staff == 'all'){
            $logs = BillDetail::with('staff', 'bill', 'service')->whereBetween('created_at', [$from, $to])->get();
        }else{
            $logs = BillDetail::with('staff', 'bill', 'service')->whereBetween('created_at', [$from, $to])
            ->where('staff_id', $request->staff)->get();       
        }
        // dd($logs);
        // ->where('deleted_at', NULL)
        return view('report.staff')->with('logs', $logs)->with('staffs', Staff::all());
    }


    public function incomeReport(){
        return view('report.income')->with('services', Service::all());
    }

    public function getIncomeReport(Request $request){
        $from = isset($request->from) ? $request->from : date("Y-m-d");
        $to = isset($request->to) ? $request->to : date("Y-m-d");

        $to = $to. ' 23:59:59';
        $from = $from. ' 00:00:00';
        if($request->service == 'all'){
            $logs = BillDetail::with('staff', 'bill', 'service')->whereBetween('created_at', [$from, $to])->get();
        }else{
            $logs = BillDetail::with('staff', 'bill', 'service')->whereBetween('created_at', [$from, $to])
            ->where('service_id', $request->service)->get();       
        }
        // dd($logs);
        // ->where('deleted_at', NULL)
        return view('report.income')->with('logs', $logs)->with('services', Service::all());
    }

   public function PLReport(){
    return view('report.pl');

   }
   public function getPLReport(Request $request){
    $from = isset($request->from) ? $request->from : date("Y-m-d");
    $to = isset($request->to) ? $request->to : date("Y-m-d");

    $to = $to. ' 23:59:59';
    $from = $from. ' 00:00:00';
    $prof = 0;
    $profit = BillProduct::whereBetween('created_at', [$from, $to])->get();
    foreach($profit as $obj){
        $prof += ($obj->qty * $obj->sell) - ($obj->qty * $obj->purchase);
    }
    return view('report.pl')->with('income', Bill::whereBetween('created_at', [$from, $to])->get()->sum('total'))
                    ->with('discount', Bill::whereBetween('created_at', [$from, $to])->get()->sum('discount'))
                    ->with('expense', Expense::whereBetween('created_at', [$from, $to])->get()->sum('amount'))
                    ->with('payment', StaffPayment::whereBetween('created_at', [$from, $to])->get()->sum('amount'))
                    ->with('profit', $prof);

   }

   public static function getStaffPercentage($staff){
        $percentages = DB::table('bill_details')
        ->select(DB::raw("sum(qty * cost * percentage_amount / 100) as total"))
        ->where('staff_id','=',$staff)
        ->get();
        return $percentages;
    }

//    public static function getStaffPercentageOLD($staff, $service, $bill_id){
//         $percentages = BillDetail::select('*')->where('staff_id', $staff)->where('service_id', $service)->where('bill_id', $bill_id)->first();
        
//         return $percentages;
//     }

    public function sellReport(){
        return view('report.sell');
    }

    public function getSellReport(Request $request){
        $from = isset($request->from) ? $request->from : date("Y-m-d");
        $to = isset($request->to) ? $request->to : date("Y-m-d");
    
        $to = $to. ' 23:59:59';
        $from = $from. ' 00:00:00';
        return view('report.sell')->with('sells', BillProduct::whereBetween('created_at', [$from, $to])->get())->with('discount', Bill::whereBetween('created_at', [$from, $to])->sum('discount'));
    }
    
    public function discountReport(){
        return view('report.discount');
    }
    
        public function getDiscountReport(Request $request){
            $from = isset($request->from) ? $request->from : date("Y-m-d");
            $to = isset($request->to) ? $request->to : date("Y-m-d");
        
            $to = $to. ' 23:59:59';
            $from = $from. ' 00:00:00';
            $bill = Bill::whereBetween('created_at', [$from, $to])->where('discount','>',0)->get();
            // dd($bill);
            return view('report.discount')->with('bills', $bill);
        }

}
