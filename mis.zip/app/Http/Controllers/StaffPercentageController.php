<?php

namespace App\Http\Controllers;

use App\Models\Service;
use App\Models\Staff;
use App\Models\StaffPercentage;
use Illuminate\Http\Request;

class StaffPercentageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('staff.percentage')->with('staff', Staff::where('type', 'percentage')->get())->with('services', Service::all())->with('staffs', StaffPercentage::all());;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        StaffPercentage::create([
            'staff_id' => $request->staff,
            'service_id' => $request->service,
            'percentage' => $request->percentage,
            'user_id' => auth()->user()->id,
        ]);
        return redirect()->route('percentage.create');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\StaffPercentage  $staffPercentage
     * @return \Illuminate\Http\Response
     */
    public function show(StaffPercentage $staffPercentage)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\StaffPercentage  $staffPercentage
     * @return \Illuminate\Http\Response
     */
    public function edit(StaffPercentage $staffPercentage)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\StaffPercentage  $staffPercentage
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, StaffPercentage $staffPercentage)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\StaffPercentage  $staffPercentage
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, StaffPercentage $staffPercentage)
    {
        dd($staffPercentage);
        dd($request->id);
        $staffPercentage = StaffPercentage::find($request->staffPercentage);
        $staffPercentage->delete();
        return redirect()->route('percentage.create');
    }
}
