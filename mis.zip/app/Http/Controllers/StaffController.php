<?php

namespace App\Http\Controllers;

use App\Models\Staff;
use App\Http\Requests\StoreStaffRequest;
use App\Http\Requests\UpdateStaffRequest;
use App\Models\BillDetail;
use App\Models\Service;
use App\Models\StaffPercentage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StaffController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('staff.index')
            ->with('staffs', Staff::all());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('staff.create')->with('services', Service::all());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreStaffRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreStaffRequest $request)
    {
        DB::transaction(function () use ($request){
        $photo ='';
        if($request->hasFile('photo')){
            $fileName = date('YmdHis').'_'.$request->name.'_'.rand(10,10000).'.'.$request->photo->extension();
            $request->photo->storeAs('images/staff', $fileName, 'public');
            $photo = 'storage/images/staff/'.$fileName;
        }
            
            $staff = Staff::create([
                'name' => $request->name,
                'last_name' => $request->last_name,
                'fathername' => $request->fathername,
                'mobile' => $request->mobile,
                'address' => $request->address,
                'type' => $request->type,
                'salary' => $request->salary,
                'file' => $photo,
                'user_id' => auth()->user()->id,
            ]);
            $i = 0;
            
            if($request->type == 'percentage'){
                $service = $request->service;
                $percentage = $request->percentage;
                foreach($service as $obj) {
                    StaffPercentage::create([
                        'staff_id' => $staff->id,
                        'service_id' => $obj,
                        'percentage' => $percentage[$i],
                        'user_id' => auth()->user()->id,
                    ]);
                    $i++;
                }
            }
        });
        return redirect()->route('staff.index')->with('success', 'کارمند موفقانه راجستر شد');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Staff  $staff
     * @return \Illuminate\Http\Response
     */
    public function show(Staff $staff)
    {
      
        return view('staff.show')->with('staffs', StaffPercentage::where('staff_id', $staff->id)->get());
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Staff  $staff
     * @return \Illuminate\Http\Response
     */
    public function edit(Staff $staff)
    {
        return view('staff.create', compact('staff'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateStaffRequest  $request
     * @param  \App\Models\Staff  $staff
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateStaffRequest $request, Staff $staff)
    {
        $photo = $staff->file;
        if($request->hasFile('photo')){
            if(file_exists(public_path().'/'.$staff->file)){
                @unlink(public_path().'/'.$staff->file);
            }
            $fileName = date('YmdHis').'_'.$request->name.'_'.rand(10,10000).'.'.$request->photo->extension();
            // $img = Image::make($request->file('photo'));
            // $img->resize(300, 300);
            // $img->save('storage/images/users/'.$fileName);
            // $photo = '/storage/images/users/'.$fileName;
            $request->photo->storeAs('images/staff', $fileName, 'public');
            $photo = 'storage/images/staff/'.$fileName;
        }
        $staff->name = $request->name;
        $staff->last_name = $request->last_name;
        $staff->fathername = $request->fathername;
        $staff->mobile = $request->mobile;
        $staff->address = $request->address;
        $staff->type = $request->type;
        $staff->status = $request->status;
        $staff->salary = $request->salary;
        $staff->file = $photo;
        $staff->save();
        return redirect()->route('staff.index')->with('success', 'معلومات کارمند موفقانه تصحیح گردید');
        // return back()->with('success', 'معلومات کارمند موفقانه تصحیح گردید');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Staff  $staff
     * @return \Illuminate\Http\Response
     */
    public function destroy(Staff $staff)
    {
        //
    }

    public static function getStaffPercentage($staff){

        $percentages = DB::table('bill_details')
            ->select(DB::raw("sum(qty * cost * percentage_amount / 100) as total"))
            ->where('staff_id','=',$staff)
            ->get();

        return $percentages;
    }

    public static function getStaffPercentageOLD($staff, $service,$bill_id){
        $percentages = BillDetail::select('*')->where('staff_id', $staff)->where('service_id', $service)->where('bill_id', $bill_id)->get();
        
        return $percentages;
    }


    public function getService(Request $request){
        $staffPercentage = StaffPercentage::find($request->staff);
        // dd($staffPercentage);
        return view('staff.service')->with('service', $staffPercentage);
    }

    public function postService(Request $request, StaffPercentage $staff_percentage){
     
        $staff_percentage->update([
            'percentage' => $request->percentage
        ]);
        return redirect()->route('staff.show',$staff_percentage->staff_id);
    }
}
