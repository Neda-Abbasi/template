<?php

namespace App\Http\Controllers;

use App\Models\Expense;
use App\Http\Requests\StoreExpenseRequest;
use App\Http\Requests\UpdateExpenseRequest;
use App\Models\ExpenseCategory;

class ExpenseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $to = date("Y-m-d").' 23:59:59';
        $from = date("Y-m-d").' 00:00:00';

        $expenses = Expense::whereBetween('created_at', [$from, $to])->get();
        return view('expense.index')->with('categories', ExpenseCategory::where('status',1)->get())->with('expenses', $expenses);
    
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreExpenseRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreExpenseRequest $request)
    {
        $photo ='';
        if($request->hasFile('photo')){
            $fileName = date('YmdHis').'_'.$request->name.'_'.rand(10,10000).'.'.$request->photo->extension();
            $request->photo->storeAs('images/expenses', $fileName, 'public');
            $photo = 'storage/images/expenses/'.$fileName;
        }

        $request->expense_date= isset($request->expense_date) ? $request->expense_date : date("Y-m-d");

        Expense::create([
            'expense_category_id' => $request->category,
            'amount' => $request->amount,
            'expense_date' => $request->expense_date,
            'description' => $request->description,
            'bill' => $photo,
            'user_id' => auth()->user()->id,
        ]);

        $to = date("Y-m-d").' 23:59:59';
        $from = date("Y-m-d").' 00:00:00';

        $expenses = Expense::whereBetween('created_at', [$from, $to])->get();
        return view('expense.index')->with('categories', ExpenseCategory::where('status',1)->get())->with('expenses', $expenses);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Expense  $expense
     * @return \Illuminate\Http\Response
     */
    public function show(Expense $expense)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Expense  $expense
     * @return \Illuminate\Http\Response
     */
    public function edit(Expense $expense)
    {
        $to = date("Y-m-d").' 23:59:59';
        $from = date("Y-m-d").' 00:00:00';

        $expenses = Expense::whereBetween('created_at', [$from, $to])->get();
        return view('expense.index')->with('categories', ExpenseCategory::where('status',1)->get())->with('expenses', $expenses)->with('expense', $expense);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateExpenseRequest  $request
     * @param  \App\Models\Expense  $expense
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateExpenseRequest $request, Expense $expense)
    {
        $photo = $expense->bill;
        // dd($expense);
        // dd($request->all());
        if($request->hasFile('photo')){
            if(file_exists(public_path().'/'.$expense->bill)){
                // dd('here');
                @unlink(public_path().'/'.$expense->bill);
            }
            // dd('out');
            $fileName = date('YmdHis').'_'.$request->name.'_'.rand(10,10000).'.'.$request->photo->extension();
            // $img = Image::make($request->file('photo'));
            // $img->resize(300, 300);
            // $img->save('storage/images/users/'.$fileName);
            // $photo = '/storage/images/users/'.$fileName;
            $request->photo->storeAs('images/expenses', $fileName, 'public');
            $photo = 'storage/images/expenses/'.$fileName;
        }

        $expense->expense_category_id = $request->category;
        $expense->amount = $request->amount;
        $expense->expense_date = $request->expense_date;
        $expense->description = $request->description;
        $expense->bill = $photo;
        $expense->save();
        return back()->with('success', 'مصرف موفقانه تصحیح گردید');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Expense  $expense
     * @return \Illuminate\Http\Response
     */
    public function destroy(Expense $expense)
    {
        //
    }
}
