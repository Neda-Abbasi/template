<?php

namespace App\Http\Controllers;

use App\Models\QueueNumber;
use App\Models\Staff;
use App\Http\Requests\StoreQueueRequest;

use Illuminate\Http\Request;

class QueueNumberController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $to = date("Y-m-d").' 23:59:59';
        $from = date("Y-m-d").' 00:00:00';
        $logs = QueueNumber::whereBetween('created_at', [$from, $to])->get();
        return view('queue.index')->with('logs',$logs)->with('staffs', Staff::where('status',1)->get());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('queue.create')->with('staffs', Staff::where('status',1)->get());
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreQueueRequest $request)
    {
        
        $to = date("Y-m-d").' 23:59:59';
        $from = date("Y-m-d").' 00:00:00';
        $number=0;
        $queueNumber = QueueNumber::whereBetween('created_at', [$from, $to])->where('staff_id',$request->staff1)->latest()->first();
        if (is_null($queueNumber)) {
            $number=$number+1;
        }else{
            $number=$queueNumber->queue_number_id+1;
        }
       $bill= QueueNumber::create([
            'queue_number_id'    =>$number,
            'staff_id' =>$request->staff1,
            'customer' =>$request->customer,
         
   
        ]);
       
        return redirect()->route('queue_number.show', $bill);
       


    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\QueueNumber  $queueNumber
     * @return \Illuminate\Http\Response
     */
    public function show(QueueNumber $queueNumber)
    {
        return view('receipt.queue_bill')->with('bill', $queueNumber);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\QueueNumber  $queueNumber
     * @return \Illuminate\Http\Response
     */
    public function edit(QueueNumber $queueNumber)
    {
        return view('queue.create')->with('queueNumber', $queueNumber)->with('staffs', Staff::where('status',1)->get());
       
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\QueueNumber  $queueNumber
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, QueueNumber $queueNumber)
    {
        $bill= QueueNumber::where('id',$queueNumber->id)->update([
          
            'staff_id' =>$request->staff1,
            'customer' =>$request->customer,
       
   
        ]);
        return redirect()->route('queue_number.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\QueueNumber  $queueNumber
     * @return \Illuminate\Http\Response
     */
    public function destroy(QueueNumber $queueNumber)
    {
        //
    }
    public function FilterQueue(Request $request)
    {
        $from = isset($request->from) ? $request->from : date("Y-m-d");
        $to = isset($request->to) ? $request->to : date("Y-m-d");
        $to = $to. ' 23:59:59';
        $from = $from. ' 00:00:00';
        if($request->staff == 'all'){
            $logs = QueueNumber::whereBetween('created_at', [$from, $to])->get();
        }else{
            $logs = QueueNumber::whereBetween('created_at', [$from, $to])
            ->where('staff_id', $request->staff)->get();       
        }
        return view('queue.index')->with('logs', $logs)->with('staffs', Staff::where('status',1)->get());
    }

}
