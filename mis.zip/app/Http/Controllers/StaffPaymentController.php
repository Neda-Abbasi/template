<?php

namespace App\Http\Controllers;

use App\Models\Staff;
use App\Models\StaffPayment;
use Illuminate\Http\Request;

class StaffPaymentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    
    public function getPayment(Request $request)
    {
        $from = isset($request->from) ? $request->from : date("Y-m-d");
        $to = isset($request->to) ? $request->to : date("Y-m-d");

        if($request->staff == 'all'){
            $logs = StaffPayment::whereBetween('pay_date', [$from, $to])->get();
        }else{
            $logs = StaffPayment::whereBetween('pay_date', [$from, $to])
            ->where('staff_id', $request->staff)->get();       
        }

        return view('payment.index')->with('logs', $logs)
                ->with('staffs', Staff::where('status',1)->get());
    }


    public function index()
    {
        return view('payment.index')
                ->with('staffs', Staff::where('status',1)->get());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // dd('here');
        return view('payment.create')->with('staffs', Staff::where('status',1)->get());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->pay_date= isset($request->pay_date) ? $request->pay_date : date("Y-m-d");
        $request->validate([
            'amount'=>'required',
        ]);

        StaffPayment::create([
            'staff_id' =>$request->staff,
            'pay_date' =>$request->pay_date,
            'amount' =>$request->amount,
            'description' =>$request->description,
            'user_id' => auth()->user()->id,
        ]);
        return redirect()->route('payment.index')->with('logs', StaffPayment::all());
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\StaffPayment  $staffPayment
     * @return \Illuminate\Http\Response
     */
    public function show(StaffPayment $staffPayment)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\StaffPayment  $staffPayment
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $staffPayment = StaffPayment::find($id);
        return view('payment.create')->with('payment', $staffPayment) ->with('staffs', Staff::all());
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\StaffPayment  $staffPayment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $staffPayment)
    {
        // dd($request);
        $request->pay_date= isset($request->pay_date) ? $request->pay_date : date("Y-m-d");
        $request->validate([
            'amount'=>'required',
        ]);
        $Payment = StaffPayment::find($staffPayment);
        // dd($Payment);
        $Payment->update([
            'staff_id' =>$request->staff,
            'pay_date' =>$request->pay_date,
            'amount' =>$request->amount,
            'description' =>$request->description,
        ]);
        return redirect()->route('payment.index')->with('staffs', Staff::all());
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\StaffPayment  $staffPayment
     * @return \Illuminate\Http\Response
     */
    public function destroy(StaffPayment $staffPayment)
    {
        //
    }
}
