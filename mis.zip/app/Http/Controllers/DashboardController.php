<?php

namespace App\Http\Controllers;

use App\Models\Bill;
use App\Models\BillDetail;
use App\Models\BillProduct;
use App\Models\Expense;
use App\Models\QueueNumber;
use App\Models\StaffPayment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{



    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $from =  date("Y-m-d"). ' 00:00:00';
        $to =  date("Y-m-d"). ' 23:59:59';

        $income = DB::table("bills")
        ->selectRaw("sum(total)-sum(discount) as income")
        ->whereBetween('created_at',[$from, $to])
        ->get();
        $allincome = DB::table("bills")
        ->selectRaw("sum(total)-sum(discount) as income")
        ->get();
       
        $bill_items = BillDetail::whereBetween('created_at', [$from, $to])->sum(DB::raw('cost * qty'));
        $products = BillProduct::whereBetween('created_at', [$from, $to])->sum(DB::raw('sell * qty'));
       
        $discount = Bill::whereBetween('created_at', [$from, $to])->sum('discount');
        $bill = $bill_items - $discount;
        //  dd($income->values('sum(total)-sum(discount)'));

        $total_queue = QueueNumber::with('staff')->whereBetween('created_at', [$from, $to])
        ->groupBy('staff_id')
        ->selectRaw('count(queue_number_id) as count, staff_id')
        ->whereBetween('created_at', [$from, $to])
        ->get('count','staff_id');
      
        return view('dashboard.index')
                ->with('expense', Expense::whereBetween('created_at', [$from, $to])->sum('amount'))
                ->with('allexpense', Expense::sum('amount'))
                ->with('bill_items', $bill)
                ->with('income', $income)
                ->with('total_queue', $total_queue)
                ->with('products', $products)
                ->with('allincome', $allincome)
                ->with('count', Bill::whereBetween('created_at', [$from, $to])->count())
                ->with('allcount', Bill::all()->count())
                ->with('payment', StaffPayment::whereBetween('created_at', [$from, $to])->sum('amount'))
                ->with('allpayment', StaffPayment::sum('amount'));
                
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
