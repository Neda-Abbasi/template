<?php

namespace App\Http\Controllers;

use App\Models\Bill;
use App\Http\Requests\StoreBillRequest;
use App\Http\Requests\UpdateBillRequest;
use App\Models\BillDetail;
use App\Models\BillProduct;
use App\Models\Product;
use App\Models\Service;
use App\Models\Staff;
use App\Models\StaffPercentage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BillController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('bill.index')->with('bills', Bill::orderBy('created_at', 'Desc')->get());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('bill.create')->with('staffs', Staff::where('type', '<>', 'servant')->where('status', 1)->get())->with('services', Service::where('status', 1)->get())->with('products', Product::where('qty', '>',0)->get());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreBillRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'grand_total' => 'required',
        ]);
        $bill = null;
        $request->validate([
            'grand_total' => 'required',
        ]);
        DB::transaction(function () use ($request, &$bill){
            $request->bill_date= isset($request->bill_date) ? $request->bill_date : date("Y-m-d");

            $goods_list = json_decode($request->hfGoodList);
            $products_list = json_decode($request->hfProductList);
            $total =0;
            $p_total =0;
            foreach ($goods_list as $k => $v) {
                $total += $v->Cost * $v->Qty;
            }
            foreach ($products_list as $k => $v) {
                $p_total += $v->p_qty * $v->p_cost;
            }
          
            $bill = Bill::create([
                'customer'=>$request->customer,
                'bill_date'=>$request->bill_date,
                'total'=>$total*1+1*$p_total,
                'discount'=>$request->discount,
                'user_id' => auth()->user()->id,
            ]);

            foreach ($goods_list as $obj) {
                $total += $p_total;
                $percentage=  StaffPercentage::where([
                    'staff_id'  =>$obj->staff_id,
                    'service_id'   =>$obj->service_id,
                ])->first();
                // dd(is_null($percentage)) ;
                if(is_null($percentage)){
                    $perc = 0;
                }else{
                    $perc = $percentage->percentage ;
                }
                // dd($percentage) ? $percentage->percentage = 0 : $percentage->percentage = $percentage->percentage ;
                BillDetail::create([
                   'bill_id' => $bill->id, 
                   'staff_id'=> $obj->staff_id, 
                   'service_id'=> $obj->service_id, 
                   'qty'=> $obj->Qty, 
                   'cost'=> $obj->Cost, 
                   'percentage_amount'=> $perc, 
                ]);
            }
            if(sizeof($products_list)){

                foreach ($products_list as $obj) {
                    BillProduct::create([
                        'bill_id' => $bill->id, 
                        'product_id'=> $obj->product_id, 
                        'qty'=> $obj->p_qty, 
                        'purchase'=> $obj->purchase, 
                        'sell'=> $obj->p_cost, 
                    ]);
                    Product::find($obj->product_id)->decrement('qty', $obj->p_qty);

                }
            }
        });
        return redirect()->route('bill.show', $bill);
        // return redirect()->route('bill.index')->with('bills', Bill::orderBy('created_at', 'Desc')->get());
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Bill  $bill
     * @return \Illuminate\Http\Response
     */
    public function show(Bill $bill)
    {
        return view('receipt.bill')->with('bill', $bill);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Bill  $bill
     * @return \Illuminate\Http\Response
     */
    public function edit(Bill $bill)
    {
        return view('bill.edit', compact('bill'))->with('staffs', Staff::all())->with('services', Service::all())->with('products', Product::where('qty', '>',0)->get());
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateBillRequest  $request
     * @param  \App\Models\Bill  $bill
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Bill $bill)
    {
        // dd($request->all());
        DB::transaction(function () use ($request, $bill){

            $products = BillProduct::where('bill_id', $bill->id)->get();
            // dd($products);
            foreach($products as $obj){
                Product::find($obj->product_id)->increment('qty', $obj->qty);

            }

            $request->bill_date= isset($request->bill_date) ? $request->bill_date : date("Y-m-d");

            $goods_list = json_decode($request->hfGoodList);
            $products_list = json_decode($request->hfProductList);
            $gtotal =0;
            $total =0;
            $p_total =0;
            // dd($products_list);
            foreach ($goods_list as $k => $v) {
                $total += $v->Cost * $v->Qty;
            }

            foreach ($products_list as $k => $v) {
                $p_total += $v->p_qty * $v->p_cost;
            }

            $gtotal = $p_total + $total;
            BillDetail::where('bill_id', $bill->id)->delete();
            BillProduct::where('bill_id', $bill->id)->delete();

            $bill->update([
                'customer'=>$request->customer,
                'bill_date'=>$request->bill_date,
                'total'=>$gtotal,
                'discount'=>$request->discount,
            ]);
            foreach ($goods_list as $obj) {
                $percentage=  StaffPercentage::where([
                    'staff_id'  =>$obj->staff_id,
                    'service_id'   =>$obj->service_id,
                ])->first();
                if(is_null($percentage)){
                    $perc = 0;
                }else{
                    $perc = $percentage->percentage;

                }
                BillDetail::create([
                   'bill_id' => $bill->id, 
                   'staff_id'=> $obj->staff_id, 
                   'service_id'=> $obj->service_id, 
                   'qty'=> $obj->Qty, 
                   'cost'=> $obj->Cost, 
                   'percentage_amount'=> $perc, 
                ]);
            }

            foreach ($products_list as $obj) {
                BillProduct::create([
                   'bill_id' => $bill->id, 
                   'product_id'=> $obj->product_id, 
                   'qty'=> $obj->p_qty, 
                   'purchase'=> $obj->purchase, 
                   'sell'=> $obj->p_cost, 
                ]);
                Product::find($obj->product_id)->decrement('qty', $obj->p_qty);
            }
            // dd($bill);
        });
        return redirect()->route('bill.index')->with('bills', Bill::orderBy('created_at', 'Desc')->get())->with('success', 'بل موفقانه ویرایش گردید.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Bill  $bill
     * @return \Illuminate\Http\Response
     */
    public function destroy(Bill $bill)
    {
        $bill->delete();
        return back()->with('success', 'بل موفقانه حذف شد');
    }
}
