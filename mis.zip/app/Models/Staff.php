<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Staff extends Model
{
    use HasFactory;
    protected $guarded=[];

    public function bill_detail(){
        return $this->hasMany(BillDetail::class);
    }

    public function staff_payment(){
        return $this->hasMany(StaffPayment::class);
    }

    public function staff_percentage(){
        return $this->hasMany(StaffPercentage::class);
    }
    
}
