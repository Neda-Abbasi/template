
<?php $__env->startSection('title', 'Product'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>
                     
                     <?php if(isset($product)): ?>
                     <?php echo e('ویرایش محصول'); ?>


                     <?php else: ?>
                     <?php echo e('ثبت و راجستر محصول'); ?>


                     <?php endif; ?>
                </h4>
                
            </div>
            <?php echo $__env->make('layouts.component.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <form class="" action="<?php echo e(isset($product) ? route('product.update', $product): route('product.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php if(isset($product)): ?>
                    <?php echo method_field('PUT'); ?>
                <?php else: ?>
                    <?php echo method_field('POST'); ?>
                <?php endif; ?>
                
                <div class="form-row align-items-center">
                    <div class="col-3">
                        <label class="" for="inlineFormInput">نام محصول</label>
                        <input type="text" class="form-control " id="inlineFormInput" name="name" value="<?php echo e(isset($product) ? $product->name: old('name')); ?>">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-3">
                        <label class="" for="inlineFormInput">قیمت خرید </label>
                        <input type="number" class="form-control " id="inlineFormInput" name="purchase" value="<?php echo e(isset($product) ? $product->purchase: old('purchase')); ?>">
                        <?php $__errorArgs = ['purchase'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-3">
                        <label class="" for="inlineFormInput">قیمت فروش </label>
                        <input type="number" class="form-control " id="inlineFormInput" name="sell" value="<?php echo e(isset($product) ? $product->sell: old('sell')); ?>">
                        <?php $__errorArgs = ['sell'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="col-3">
                        <label class="" for="inlineFormInputGroup"> تعداد</label>
                        <input type="number" class="form-control " id="qty" name="qty"  value="<?php echo e(isset($product) ? $product->qty: old('qty')); ?>">
                        <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="col-3">
                        <label class="" for="inlineFormInputGroup"> حداقل موجود</label>
                        <input type="number" class="form-control " id="min_stock" name="min_stock"  value="<?php echo e(isset($product) ? $product->min_stock: old('min_stock')); ?>">
                        <?php $__errorArgs = ['min_stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  
                    <div class="col-2">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block <?php echo e(isset($product) ?'f-primary':'f-secondary'); ?> text-center"> <?php echo e(isset($product) ?'ویرایش':'ثبت'); ?></button>
                    </div>
                </div>
            </form>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nethub Desktop\Documents\GitHub\Barber\resources\views/product/create.blade.php ENDPATH**/ ?>