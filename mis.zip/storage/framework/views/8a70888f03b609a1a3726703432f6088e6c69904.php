<div class="row m-2 mb-1">
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 p-2">
        <?php if(session()->has('success')): ?>

            <div class="alert text-dir-rtl text-center  alert-first alert-shade alert-dismissible fade show" role="alert">
                <strong><?php echo e(session('success')); ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
        <?php elseif(session()->has('error')): ?>
            <div class="alert text-dir-rtl text-center  alert-third alert-shade alert-dismissible fade show" role="alert">
                <strong><?php echo e(session('error')); ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>

        <?php endif; ?>
    </div>
</div><?php /**PATH C:\Users\Nethub Desktop\Documents\GitHub\Barber\resources\views/layouts/component/alert.blade.php ENDPATH**/ ?>