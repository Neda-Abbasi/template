
<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row mb-2">
        <div class="col-xl-3 col-md-6 col-sm-6 p-2">
            <div class="box-dash animate__animated animate__flipInY b-first  "><i class="fab far fa-chart-bar" aria-hidden="true"></i>

                <span><?php echo e(isset($income->first()->income)? $income->first()->income : 0); ?></span>
                <!-- <span><?php echo e(isset($bill_items)? $bill_items : 0); ?></span> -->
                <hr class="m-0 ">
                <span>عواید </span>
                <a href="<?php echo e(route('report.income')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 col-sm-6 p-2">
            <div class="box-dash animate__animated animate__flipInY b-second   "><i class="fab far fa-clock" aria-hidden="true"></i>

                <span><?php echo e($expense); ?></span>
                <hr class="m-0 ">
                <span>مصارف </span>
                <a href="<?php echo e(route('report.income')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 col-sm-6 p-2">
            <div class="box-dash animate__animated animate__flipInY b-third  "><i class="fab far fa-comments" aria-hidden="true"></i>
                <span><?php echo e($payment); ?></span>
                <hr class="m-0 ">
                <span> پرداخت کارمند</span>
                <a href="" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 col-sm-6 p-2">
            <div class="box-dash animate__animated animate__flipInY b-forth  "><i class="fab far fa-gem" aria-hidden="true"></i>

                <?php $balance = $income->first()->income - $expense - $payment- $products; ?>
                <span><?php echo e($balance); ?></span>
                <hr class="m-0 ">
                <span>بلانس</span>
                <a href="<?php echo e(route('bill.index')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 col-sm-6 p-2">
            <div class="box-dash animate__animated animate__flipInY b-forth  "><i class="fab far fa-gem" aria-hidden="true"></i>
                <span><?php echo e($products); ?></span>
                <hr class="m-0 ">
                <span>محصولات</span>
                <a href="<?php echo e(route('bill.index')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <div class="col-xl-6 col-md-6 col-sm-6 p-2 bg-white">
         
                <?php if(isset($total_queue)): ?>

                <table class="table table-sm table-striped table-bordered">
                    <thead>
                        <tr>
                            <th scope="col"> #</th>
                            <th scope="col">اسم کارمند</th>
                            <th scope="col">تعداد</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // dd($logs)
                        $withdraw = 0;
                        $deposit = 0;
                        $tot = 0;
                        ?>
                        <?php if(isset($total_queue)): ?>

                        <?php $__currentLoopData = $total_queue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <tr>
                            <td><?php echo e($k+1); ?></td>
                            <td><?php echo e($v->staff->name); ?></td>
                            <td><?php echo e($v->count); ?> </td>
                        </tr>
                        <?php $tot +=$v->count; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th></th>
                            <th>جمله</th>
                            <th><?php echo e($tot); ?></th>
                        </tr>
                    </tfoot>
                </table>
                <?php endif; ?>

        </div>

    </div>

    <div class="row m-1 my-5 d-none">
        <div class="col-xl-3 col-md-6 col-sm-6 p-2">
            <div class="box-card text-right mini animate__animated animate__flipInY   "><i class="fab far fa-chart-bar b-first" aria-hidden="true"></i>
                <span class="mb-1 c-first">عواید</span>
                <span><?php echo e(isset($allincome->first()->income)? $allincome->first()->income : 0); ?></span>

                <p class="mt-3 mb-1 text-right"><i class="far fas fa-wallet mr-1 c-first"></i> در حال
                    پیشرفت</p>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 col-sm-6 p-2">
            <div class="box-card text-right mini animate__animated animate__flipInY    "><i class="fab far fa-clock b-second" aria-hidden="true"></i>
                <span class="mb-1 c-second">مصارف</span>
                <span><?php echo e($allexpense); ?></span>
                <p class="mt-3 mb-1 text-right"><i class="far fas fa-wifi mr-1 c-second"></i>در حال پیشرفت
                </p>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 col-sm-6 p-2">
            <div class="box-card text-right mini animate__animated animate__flipInY   "><i class="fab far fa-comments b-third" aria-hidden="true"></i>
                <span> پرداخت کارمند</span>
                <span><?php echo e($allpayment); ?></span>
                <p class="mt-3 mb-1 text-right"><i class="fab fa-whatsapp mr-1 c-third"></i>در حال پیشرفت
                </p>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 col-sm-6 p-2">
            <div class="box-card text-right mini animate__animated animate__flipInY   "><i class="fab far fa-gem b-forth" aria-hidden="true"></i>
                <span class="mb-1 c-third"> بلانس</span>
                <?php $balance = $allincome->first()->income - $allexpense -$allpayment; ?>
                <span><?php echo e($balance); ?></span>
                <p class="mt-3 mb-1 text-right"><i class="fab fa-bluetooth mr-1 c-forth"></i>در حال پیشرفت
                </p>
            </div>
        </div>
    </div>
    <!-- row closed-->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nethub Desktop\Documents\GitHub\Barber\resources\views/dashboard/index.blade.php ENDPATH**/ ?>