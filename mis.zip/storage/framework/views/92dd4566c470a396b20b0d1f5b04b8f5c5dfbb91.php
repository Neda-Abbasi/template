
<div id="dw-s1" class="bmd-layout-drawer bg-faded ">

    <div class="container-fluid side-bar-container ">
        <header class="pb-0">
            <a class="navbar-brand ">
                
                <img src="<?php echo e(asset('img/logo1.png')); ?>" alt="" class="side-logo" >
            </a>
        </header>
        <li class="side a-collapse short m-2 pr-1 pl-1">
            <a href="<?php echo e(route('dashboard.index')); ?>" class="side-item selected c-dark "><i class="fas fa-tachometer-alt  mr-1"></i>داشبورد </a>
        </li>
        <li class="side a-collapse short ">
            <a href="<?php echo e(route('service.index')); ?>" class="side-item "><i class="fas fa-cube  mr-1"></i>خدمات </a>
        </li>
        
        </ul>
     
        <ul class="side a-collapse short ">
            <a class="ul-text  fnt-mxs"><i class="fas fa-money-bill mr-1"></i>  مالی 
            <i class="fas fa-chevron-down arrow"></i></a>
            <div class="side-item-container hide animated">
                <li class="side-item"><a href="<?php echo e(route('bill.create')); ?>" class="fnt-mxs"><i
                            class="fas fa-angle-right mr-2"></i>بل جدید</a>
                </li>
                <li class="side-item"><a href="<?php echo e(route('bill.index')); ?>" class="fnt-mxs"><i
                            class="fas fa-angle-right mr-2"></i>لست بل ها</a></li>

            </div>
        </ul>
     
        <ul class="side a-collapse short ">
            <a class="ul-text  fnt-mxs"><i class="fas fa-users mr-1"></i>  کارمندان 
            <i class="fas fa-chevron-down arrow"></i></a>
            <div class="side-item-container hide animated">
                <li class="side-item"><a href="<?php echo e(route('staff.create')); ?>" class="fnt-mxs"><i
                            class="fas fa-angle-right mr-2"></i>کارمند جدید</a>
                </li>
                <li class="side-item"><a href="<?php echo e(route('staff.index')); ?>" class="fnt-mxs"><i
                            class="fas fa-angle-right mr-2"></i>لست کارمندان</a></li>

                <li class="side-item"><a href="<?php echo e(route('payment.create')); ?>" class="fnt-mxs"><i
                               class="fas fa-angle-right mr-2"></i>پرداخت برای کارمند</a></li>
                               
                <li class="side-item"><a href="<?php echo e(route('payment.index')); ?>" class="fnt-mxs"><i
                            class="fas fa-angle-right mr-2"></i>لست پرداخت ها </a></li>

            </div>
        </ul>
        
        <ul class="side a-collapse short ">
            <a class="ul-text  fnt-mxs"><i class="fas fa-shopping-basket mr-1"></i> مصارف 
            <i class="fas fa-chevron-down arrow"></i></a>
            <div class="side-item-container hide animated">
                <li class="side-item"><a href="<?php echo e(route('expense.index')); ?>" class="fnt-mxs"><i
                            class="fas fa-angle-right mr-2"></i>مصارف</a>
                </li>
                <li class="side-item"><a href="<?php echo e(route('category.index')); ?>" class="fnt-mxs"><i
                            class="fas fa-angle-right mr-2"></i> کتگوری مصارف </a></li>
            </div>
        </ul>
        <ul class="side a-collapse short ">
            <a class="ul-text  fnt-mxs"><i class="fas fa-cubes mr-1"></i> محصولات 
            <i class="fas fa-chevron-down arrow"></i></a>
            <div class="side-item-container hide animated">
                <li class="side-item"><a href="<?php echo e(route('product.create')); ?>" class="fnt-mxs"><i
                            class="fas fa-angle-right mr-2"></i>افزودن محصول</a>
                </li>
                <li class="side-item"><a href="<?php echo e(route('product.index')); ?>" class="fnt-mxs"><i
                            class="fas fa-angle-right mr-2"></i>لست محصولات</a></li>
            </div>
        </ul>
        <ul class="side a-collapse short ">
            <a class="ul-text  fnt-mxs"><i class="fas fa-cubes mr-1"></i> نوبت گیری  
            <i class="fas fa-chevron-down arrow"></i></a>
            <div class="side-item-container hide animated">
                <li class="side-item"><a href="<?php echo e(route('queue_number.create')); ?>" class="fnt-mxs"><i
                            class="fas fa-angle-right mr-2"></i>افزودن نوبت</a>
                </li>
                <li class="side-item"><a href="<?php echo e(route('queue_number.index')); ?>" class="fnt-mxs"><i
                            class="fas fa-angle-right mr-2"></i>لست نوبت</a></li>
            </div>
        </ul>
        <ul class="side a-collapse short ">
            <a class="ul-text  fnt-mxs"><i class="fas fa-file-alt mr-1"></i> راپور ها 
            <i class="fas fa-chevron-down arrow"></i></a>
            <div class="side-item-container hide animated">
                <li class="side-item"><a href="<?php echo e(route('report.income')); ?>" class="fnt-mxs"><i
                            class="fas fa-angle-right mr-2"></i> راپور عواید</a>
                </li>
                <li class="side-item"><a href="<?php echo e(route('report.staff')); ?>" class="fnt-mxs"><i
                            class="fas fa-angle-right mr-2"></i> راپور کارمندان</a>
                </li>
                <li class="side-item"><a href="<?php echo e(route('report.expense')); ?>" class="fnt-mxs"><i
                            class="fas fa-angle-right mr-2"></i>  راپور  مصارف </a>
                </li>
                <li class="side-item"><a href="<?php echo e(route('report.expense_category')); ?>" class="fnt-mxs"><i
                            class="fas fa-angle-right mr-2"></i>  راپور  مصارف به اساس کتگوری</a>
                </li>
                <li class="side-item"><a href="<?php echo e(route('report.sell')); ?>" class="fnt-mxs"><i
                            class="fas fa-angle-right mr-2"></i>  راپور  فروشات </a>
                </li>
                <li class="side-item"><a href="<?php echo e(route('report.discount')); ?>" class="fnt-mxs"><i
                            class="fas fa-angle-right mr-2"></i>  راپور  تخفیف </a>
                </li>
                <li class="side-item"><a href="<?php echo e(route('report.pl')); ?>" class="fnt-mxs"><i
                            class="fas fa-angle-right mr-2"></i>  راپور  مفاد و ضرر </a>
                </li>
            </div>
        </ul>
        <li class="side a-collapse short ">
            <a href="<?php echo e(route('backup')); ?>" class="side-item "><i class="fas fa-download mr-1"></i> بک اپ (نسخه پشتیبان)</a>
        </li>
        <li class="side a-collapse short ">
            <a href="<?php echo e(route('logout')); ?>" class="side-item "><i class="fas fa-sign-out-alt mr-1"></i>خروج</a>
        </li>
        <p class="side-comment"><a href="https://nethub.af" target="_blank"> Developed by Nethub</a></p>

    </div>

</div><?php /**PATH C:\Users\Nethub Desktop\Documents\GitHub\Barber\resources\views/layouts/nav.blade.php ENDPATH**/ ?>