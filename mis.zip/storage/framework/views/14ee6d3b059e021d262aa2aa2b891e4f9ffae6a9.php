<!doctype html>
<html class="no-js" lang="">
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('title', 'Sarafi MIS Login'); ?>
<body class="gradient rtl" style="overflow: hidden">

	<div class="bmd-layout-container bmd-drawer-f-l avam-container animated ">
		<main class="bmd-layout-content">
			<div class="container-fluid">
				<div class="main_wrapper">

					
                    <!-- form -->

                    <div class="row ">
                        <div class="col-md-5 card shade mw-center mh-center">
                            <?php echo $__env->make('layouts.component.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <img src="<?php echo e(asset('img/logo.jpeg')); ?>" alt="..." class="mw-center " height="" width="200" >
                            <hr class="hr-dashed m-0">
                            <form class="" action="<?php echo e(route('login')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group m-0">
                                    <label for="exampleInputEmail1">نام کاربر</label>
                                    <input type="text" class="form-control" id="exampleInputEmail1"
                                        aria-describedby="emailHelp" name="name">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="alert text-danger "><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group m-0">
                                    <label for="exampleInputPassword1">رمز کاربر</label>
                                    <input type="password" class="form-control" id="exampleInputPassword1" name="password">
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="alert text-danger "><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-check pt-2">
                                    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="remember">
                                    <label class="form-check-label" for="exampleCheck1">بخاطر بسپار</label>
                                </div>
                                <button type="submit" class="btn shade f-primary btn-block text-center">ارسال</button>
                            </form>
                            <div class="col-12 text-center pb-2">

                                <a href="https://nethub.af" style="text-align: center;" target="_blank"> Developed by Nethub</a>
                            </div>
                        </div>

                    </div>
                    <!--  -->


				</div>

			</div>
		</main>
	</div>

	</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>

<?php /**PATH C:\Users\Nethub Desktop\Documents\GitHub\Barber\resources\views/auth/login.blade.php ENDPATH**/ ?>