
<?php $__env->startSection('title', 'service'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>
                     <?php echo e('ثبت خدمات کارمند'); ?>

                </h4>
                
            </div>
            <?php echo $__env->make('layouts.component.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <form class="" action="<?php echo e(route('percentage.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                
                <div class="form-row align-items-center">
                    <div class="col-6  col-sm-3">
                        <label class="" for="inlineFormInputGroup">کارمند </label>
                        <select class="form-control " name="staff" id="staff">
                            <option value="">انتخاب نمایید</option>
                            <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($staf->id); ?>" ><?php echo e($staf->name); ?> <?php echo e($staf->last_name); ?> </option>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>    
                        <?php $__errorArgs = ['staff'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-6  col-sm-3">
                        <label class="" for="inlineFormInputGroup">خدمات </label>
                        <select class="form-control " name="service" id="service">
                            <option value="">انتخاب نمایید</option>
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($service->id); ?>" data-cost="<?php echo e($service->cost); ?>"><?php echo e($service->name); ?> </option>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>    
                        <?php $__errorArgs = ['service'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  
                    <div class="col-3">
                        <label class="" for="inlineFormInputGroup"> فیصدی</label>
                        <input type="number" step="0.1" class="form-control " id="percentage" name="percentage"  value="<?php echo e(old('percentage')); ?>">
                        <?php $__errorArgs = ['percentage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-3">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block f-primary text-center">ثبت</button>
                    </div>
                </div>
            </form>

            <table class="table table-sm table-striped table-bordered" id="">
                <thead>
                    <tr>
                        <th scope="col">نام</th>
                        <th scope="col">خدمات</th>
                        <th scope="col">فیصدی</th>
                        <th scope="col">عمل</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    <tr>
                        <td><?php echo e($staff->staff->name); ?></td>
                        <td><?php echo e($staff->service->name); ?> </td>
                        <td><?php echo e($staff->percentage); ?></td>
                        <td class="d-flex"><a href="<?php echo e(route('staff.service.get', $staff)); ?>" title="ویرایش" class="btn btn-success btn-sm" style="height: 35px;"><i class="fa fa-edit"></i></a>  
                            
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
            </table>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nethub Desktop\Documents\GitHub\Barber\resources\views/staff/percentage.blade.php ENDPATH**/ ?>