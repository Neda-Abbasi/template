
<?php $__env->startSection('title', 'Expense Category'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>

                    کتگوری مصارف
                </h4>
                
                <?php if($errors->any()): ?>
                <div class="text-center">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="text-danger"> <?php echo e($error); ?> </span><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>
            <?php echo $__env->make('layouts.component.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <form action="<?php echo e(isset($category) ? route('category.update', $category->id) : route('category.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php if(isset($category)): ?>
                <?php echo method_field('PUT'); ?>
                <?php else: ?>
                <?php echo method_field('POST'); ?>
                <?php endif; ?>

                <div class="form-row align-items-center">
                    <div class="col-3">
                        <label class="" for="inlineFormInput">نام کتگوری</label>
                        <input type="text" class="form-control " id="inlineFormInput" name="name" value="<?php echo e(isset($category) ? $category->name: old('name')); ?>">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <?php if(isset($category)): ?>
                    <div class="col-12 col-sm-4 col-md-3 mt-3">
                        <label class="" for="inlineFormInputGroup"> </label>

                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" <?php if($category->status == 1): ?><?php echo e('checked'); ?> <?php endif; ?> name="status" id="deposit" value="1">
                            <label class="form-check-label" for="deposit">
                                فعال
                            </label>
                        </div>
                        <div class="form-check  form-check-inline">
                            <input class="form-check-input" type="radio" <?php if($category->status == 0): ?><?php echo e('checked'); ?> <?php endif; ?> name="status" id="withdraw" value="0">
                            <label class="form-check-label" for="withdraw">
                                غیرفعال
                            </label>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="col-1">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block <?php echo e(isset($category) ?'f-primary':'f-secondary'); ?> text-center"> <?php echo e(isset($category) ?'ویرایش':'ثبت'); ?></button>
                    </div>
                </div>
            </form>

            <h5 class="card-title">لست صرافان</h5>

            <hr>
            <table class="table table-sm table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">نام</th>
                        <th scope="col">حالت</th>
                        <th scope="col">عمل</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $c = 1 ?>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <th scope="row"><?php echo e($c++); ?> </th>
                        <td><?php echo e($category->name); ?></td>
                        <td><?php if($category->status == 1): ?> <?php echo e('فعال'); ?> <?php else: ?><?php echo e('غیر فعال'); ?> <?php endif; ?></td>
                        <td><a href="<?php echo e(route('category.edit', $category)); ?>" title="ویرایش" class="btn btn-success btn-sm"><i class="fa fa-edit"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>


        </div>



    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nethub Desktop\Documents\GitHub\Barber\resources\views/category/index.blade.php ENDPATH**/ ?>