<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title><?php echo $__env->yieldContent('title'); ?> | Barber MIS</title>
	
	<meta name="description" content="nozha admin panel fully support rtl with complete dark mode css to use. ">
	<meta name=”robots” content="index, follow">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('/img/favicon/apple-touch-icon.png')); ?>">
	<link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('/img/favicon/favicon-32x32.png')); ?>">
	<link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('/img/favicon/favicon-16x16.png')); ?>">
	<link rel="manifest" href="<?php echo e(asset('/img/favicon/site.webmanifest')); ?>">
	<link rel="mask-icon" href="<?php echo e(asset('/img/favicon/safari-pinned-tab.svg')); ?>" color="#5bbad5">
	<meta name="msapplication-TileColor" content="#2b5797">
	<meta name="theme-color" content="#ffffff">
	<!-- Place favicon.ico in the root directory -->
	<link rel="stylesheet" href="<?php echo e(asset('/css/normalize.css')); ?>">
	<link href="<?php echo e(asset('/css/fontawsome/all.min.css')); ?>" rel="stylesheet">
	<link rel="stylesheet"
		href="<?php echo e(asset('/css/bootstrap-material-design.min.css')); ?>">

	<link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>">
	<link href="<?php echo e(asset('/css/toastr.min.css')); ?>" rel="stylesheet" />

	<link rel="stylesheet" href="<?php echo e(asset('/css/animate.min.css')); ?>" />
	<link rel="stylesheet" href="<?php echo e(asset('/css/select2.min.css')); ?>" />
	<link rel="stylesheet" href="<?php echo e(asset('/js/datatable/css/buttons.dataTables.min.css')); ?>" />
	<link rel="stylesheet" href="<?php echo e(asset('/js/datatable/css/jquery.dataTables.min.css')); ?>" />

	<link rel="stylesheet" href="<?php echo e(asset('/css/main.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
</head><?php /**PATH C:\Users\Nethub Desktop\Documents\GitHub\Barber\resources\views/layouts/header.blade.php ENDPATH**/ ?>