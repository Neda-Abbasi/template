
<?php $__env->startSection('title', 'Staff Performance'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>
                    راپور کارمندان
                </h4>
                <?php if($errors->any()): ?>
                    <?php echo e(implode('', $errors->all('<div>:message</div>'))); ?>

                <?php endif; ?>
            </div>

            <?php 
            // dd($logs);
            ?>
            <?php echo $__env->make('layouts.component.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <form class="" action="<?php echo e(route('report.getStaff')); ?>" method="POST" >
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                
                <div class="form-row align-items-center">
                    <div class="col-3">
                        <label class="" for="inlineFormInputGroup">کارمند </label>
                        <select class="form-control select2" name="staff" id="staff">
                            <option value="all">همه</option>
                            <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($staff->id); ?>" ><?php echo e($staff->name); ?> <?php echo e($staff->last_name); ?> </option>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>    
                        <?php $__errorArgs = ['from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-4">
                        <label class="" for="inlineFormInput">از تاریخ</label>
                        <input type="date" class="form-control " name="from">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  
                    <div class="col-4">
                        <label class="" for="inlineFormInputGroup">الی تاریخ</label>
                        <input type="date" class="form-control " name="to">
                        <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="col-1">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block f-primary text-center"> ارسال</button>
                    </div>
                </div>
                

            </form>
            <?php if(isset($logs)): ?>
                
                <table class="table table-sm table-striped table-bordered display compact" id="datatable-report">
                    <thead>
                        <tr>
                            <th scope="col">تاریخ </th>
                            <th scope="col">بل </th>
                            <th scope="col"> کارمند</th>
                            
                            <th scope="col"> خدمات</th>
                            <th scope="col"> نرخ</th>
                            <th scope="col"> فیصدی</th>
                            <th scope="col">تعداد </th>
                            <th scope="col"> جمله</th>
                            <th scope="col"> فیصدی</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $gtotal = 0;
                        $gper = 0;
                        $total = 0;
                        $perc = 0;
                        ?>
                        <?php if(isset($logs)): ?>
                            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(date('d-m-Y', strtotime($log->created_at))); ?></td>
                            <td><?php echo e($log->bill->id); ?></td>
                            <td><?php echo e($log->staff->name); ?></td>
                            
                            <td><?php echo e($log->service->name); ?></td>
                            <td><?php echo e($log->cost); ?></td>
                            <td><?php echo e($log->percentage_amount); ?></td>
                            <td><?php echo e($log->qty); ?></td>
                            <td><?php echo e($total = $log->cost * $log->qty); ?> </td>
                            <td>    
                            
                                
                                <?php echo e($perc = $total*$log->percentage_amount/100); ?>

                            </td>
                        </tr>
                            <?php 
                            $gtotal +=$total;
                            $gper +=$perc;
                            ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th>جمله</th>
                            <th><?php echo e($gtotal); ?></th>
                            <th><?php echo e($gper); ?></th>
                        </tr>
                    </tfoot>
                </table>
            <?php endif; ?>

        </div>



    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nethub Desktop\Documents\GitHub\Barber\resources\views/report/staff.blade.php ENDPATH**/ ?>