
<?php $__env->startSection('title', 'Expense'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>
                     ثبت مصارف
                </h4>
                
                <?php if($errors->any()): ?>
                <div class="text-center">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="text-danger"> <?php echo e($error); ?> </span><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>
            <?php echo $__env->make('layouts.component.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <form action="<?php echo e(isset($expense) ? route('expense.update', $expense) : route('expense.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php if(isset($expense)): ?>
                    <?php echo method_field('PUT'); ?>
                <?php else: ?>
                    <?php echo method_field('POST'); ?>
                <?php endif; ?>
                
                <div class="form-row align-items-center">
                    <div class="col-3">
                        <label class="" for="inlineFormInputGroup">تاریخ </label>
                        <input type="date" class="form-control " name="expense_date"  value="<?php echo e(isset($expense) ? $expense->expense_date: old('expense_date')); ?>">
                        <?php $__errorArgs = ['expense_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-3">
                        <label class="" for="inlineFormInputGroup">کتگوری </label>
                        <select class="form-control " name="category" id="category">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>" <?php if(isset($expense)): ?> <?php if($expense->expense_category_id == $category->id): ?> selected="selected" <?php endif; ?> <?php endif; ?>><?php echo e($category->name); ?></option>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>    
                        <?php $__errorArgs = ['doc_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-6">
                        <label class="" for="inlineFormInput">تفصیلات</label>
                        <input type="text" class="form-control " id="inlineFormInput" name="description" value="<?php echo e(isset($expense) ? $expense->description: old('description')); ?>">
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-3">
                        <label class="" for="fathername"> مبلغ</label>
                        <input type="number" class="form-control " id="amount" name="amount" value="<?php echo e(isset($expense) ? $expense->amount: old('amount')); ?>">
                        <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                   
                    <div class="col-5">
                        <label class="" for="inlineFormInputGroup"> بل</label>
                        <input type="file" class="form-control " name="photo" >
                        <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="col-1">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block <?php echo e(isset($expense) ?'f-primary':'f-secondary'); ?> text-center"> <?php echo e(isset($expense) ?'ویرایش':'ثبت'); ?></button>
                    </div>
                </div>

            </form>
    
            <h5 class="card-title">لست مصارفات</h5>

            <hr>
            <table class="table table-sm table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">کتگوری</th>
                        <th scope="col">تفصیلات</th>
                        <th scope="col">مبلغ</th>
                        <th scope="col">تاریخ</th>
                        <th scope="col">عمل</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $c = 1 ?>
                    <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    <tr>
                        <td scope="row"><?php echo e($c++); ?> </td>
                        <td><?php echo e($expense->expense_category->name); ?></td>
                        <td><?php echo e($expense->description); ?> </td>
                        <td><?php echo e($expense->amount); ?> </td>
                        <td><?php echo e(date('d-m-Y', strtotime($expense->expense_date))); ?></td>

                        <td><a href="<?php echo e(route('expense.edit', $expense)); ?>" title="ویرایش" class="btn btn-success btn-sm"><i class="fa fa-edit"></i></a>  
                        
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
            </table>
            

        </div>



    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nethub Desktop\Documents\GitHub\Barber\resources\views/expense/index.blade.php ENDPATH**/ ?>