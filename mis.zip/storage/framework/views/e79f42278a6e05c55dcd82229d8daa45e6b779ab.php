
<?php $__env->startSection('title', 'Product List'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">

            <?php echo $__env->make('layouts.component.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <h4 class="card-title">لست محصولات</h4>

            <hr>
            <table class="table table-sm table-striped table-bordered" id="datatable">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">کود</th>
                        <th scope="col">نام </th>
                        <th scope="col">قیمت خرید</th>
                        <th scope="col">قیمت فروش</th>
                        <th scope="col">تعداد موجود</th>
                        <th scope="col">حداقل موجود</th>
                        <th scope="col">عمل</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $c = 1; 
                    ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $color = ''; if($product->qty <= $product->min_stock){$color='#e58181';} ?> 
                    <tr style="background:<?php echo e($color); ?>">
                        <td scope="row"><?php echo e($c++); ?> </td>
                        <td><?php echo e($product->id); ?> </td>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->purchase); ?></td>
                        <td><?php echo e($product->sell); ?></td>
                        <td><?php echo e($product->qty); ?></td>
                        <td><?php echo e($product->min_stock); ?></td>
                        
                        <td><a href="<?php echo e(route('product.edit', $product)); ?>" title="ویرایش" class="btn btn-success btn-sm"><i class="fa fa-edit"></i></a>  
                        
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
            </table>
            
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nethub Desktop\Documents\GitHub\Barber\resources\views/product/index.blade.php ENDPATH**/ ?>