

	<script src="<?php echo e(asset('/js/vendor/modernizr.js')); ?>"></script>
	<script src="<?php echo e(asset('/js/jquery-3.2.1.min.js')); ?>"></script>
	
	
	
	<script src="<?php echo e(asset('/js/popper.js')); ?>">
	</script>
	
	<script src="<?php echo e(asset('/js/bootstrap-material-design.js')); ?>">
	</script>
	
	<script>
		$(document).ready(function () {
			$('body').bootstrapMaterialDesign();
		});
	</script>
	
	<script src="<?php echo e(asset('/js/select2.min.js')); ?>"></script>
	<script src="<?php echo e(asset('/js/main.js')); ?>"></script>
	
	<script src="<?php echo e(asset('/js/datatable/js/jquery.dataTables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('/js/datatable/js/dataTables.buttons.min.js')); ?>"></script>
	<script src="<?php echo e(asset('/js/datatable/js/jszip.min.js')); ?>"></script>
	<script src="<?php echo e(asset('/js/datatable/js/pdfmake.min.js')); ?>"></script>
	<script src="<?php echo e(asset('/js/datatable/js/vfs_fonts.js')); ?>"></script>
	<script src="<?php echo e(asset('/js/datatable/js/buttons.html5.min.js')); ?>"></script>
	<script src="<?php echo e(asset('/js/datatable/js/buttons.print.min.js')); ?>"></script>
<?php /**PATH C:\Users\Nethub Desktop\Documents\GitHub\Barber\resources\views/layouts/footer.blade.php ENDPATH**/ ?>