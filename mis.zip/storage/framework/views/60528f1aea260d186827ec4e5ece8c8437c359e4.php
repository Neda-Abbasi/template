<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Receipt</title>
	<!-- Tell the browser to be responsive to screen width -->
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<!-- Bootstrap 3.3.6 -->
	<link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>">
	<!-- Font Awesome -->
	
	
	<link rel="stylesheet" href="<?php echo e(asset('/css/print.css')); ?>">
</head>
<script type="text/javascript">

        window.onafterprint = back;

        function back() {
            // window.history.back(); //It goes one step back which again prompts for form submission
			// window.history.go(-2);
			document.location.href ='/bill/create';
        }
    </script>
<body onload="window.print();">
	<!--
<body>-->
	<div class="wrapper">
		<!-- Main content -->
		<section class="invoice">
			

			<!-- /.row -->
			<div class="print-box jsBillPrintBox cook-bill">
				<table class="print-tbl restaurant-specs" border="1">
					<tbody>
						<tr>
							<td class="sbold text-center"><img src="<?php echo e(asset('img/logo.jpg')); ?>" width="80%"></td>
						</tr>
						
					</tbody>
				</table>
			
				<br>
				<table class="print-tbl"  border="1">
					<tbody class="jsBillItems" dir="rtl">
						
						<tr>
							<td  colspan="5">بل : <span class="jsBillNo"><?php echo e($bill->id); ?></span> </td>
						</tr>
						<tr>
							<td colspan="5">مشتری : <span class="jsOrderType"><?php echo e($bill->customer); ?></span> </td>
						</tr>
						<tr>
							<td class="mrl5">خدمات</td>
							<td class="mrl5 ">تعداد</td>
							<td class="mrl5">نرخ</td>
							<!-- <td class="mrl5">فیصدی</td> -->
							<td class="mrl5">جمله</td>
						</tr>

						<tr>
							
						<?php $__currentLoopData = $bill->bill_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							</tr>
							<td class="mrl5"><?php echo e($obj->service->name); ?></td>
								<td class="mrl5"><?php echo e($obj->qty); ?></td>
								<td class="mrl5"><?php echo e($obj->cost); ?></td>
								<!-- <td class="mrl5"><?php echo e($obj->percentage_amount); ?></td> -->
								<td class="mrl5"><?php echo e($obj->qty * $obj->cost); ?></td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php if($bill->bill_product->isNotEmpty()): ?>
							<?php $__currentLoopData = $bill->bill_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								</tr>
								<td class="mrl5"><?php echo e($obj->product->name); ?></td>
									<td class="mrl5"><?php echo e($obj->qty); ?></td>
									<td class="mrl5"><?php echo e($obj->sell); ?></td>
									<td class="mrl5"><?php echo e($obj->qty * $obj->sell); ?></td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
						<tr>
							<td class="text-right" colspan="2">مجموع کل: </td>
							<td class="text-right jsSubTotal" colspan="3"><?php echo e($bill->total); ?></td>
						</tr>
						 <?php if($bill->discount > 0): ?> 
						<tr>
							<td class="text-right" colspan="2">تخفیف: </td>
							<td class="text-right jsSubTotal"colspan="2"><?php echo e($bill->discount); ?></td>
						</tr>
						<?php endif; ?>
						<tr>
							<td class="text-right" colspan="2">پرداختی: </td>
							<td class="text-right jsSubTotal"colspan="3"><?php echo e($bill->total-$bill->discount); ?></td>
						</tr>
						
					</tbody>
				</table>
				
				<table class="print-tbl restaurant-specs ">
					<tbody>
						<tr>
							<td class="text-center"> رضایت شما افتخار ماست </td>
						</tr>
						<tr>
							<td class="text-center">شماره تماس: 0780621421</td>
						</tr>
						<tr>
							<td class="text-center">آدرس: پل محمودخان گلبهار تاورز کابل افغانستان</td>
						</tr>
						<tr>
							<td dir="ltr" class="text-center"><img src="<?php echo e(asset('/img/fb.png')); ?>" />: New York hair salon</td>
						</tr>
						
					</tbody>
				</table>
				<table class="print-tbl" dir="rtl">
					<tbody>
						<tr>
							<td class="dotted full" colspan="4">
								<hr />
							</td>
						</tr>
						<tr>
							<td> تاریخ : <span class="jsBillDate"><?php echo e(date('d-m-Y', strtotime($bill->created_at))); ?></span></td>
							<td> ساعت : <span class="jsBillDate" dir="ltr"><?php echo e(date('h : i ', strtotime($bill->created_at))); ?></span></td>
						</tr>
						<tr>
							<td class="dotted full" colspan="4">
								<hr />
							</td>
						</tr>
					</tbody>
				</table>
			</div>

			<!-- /.row -->
		</section>
		<!-- /.content -->
	</div>
	<!-- ./wrapper -->
</body>

</html>
<?php /**PATH C:\Users\Nethub Desktop\Documents\GitHub\Barber\resources\views/receipt/bill.blade.php ENDPATH**/ ?>