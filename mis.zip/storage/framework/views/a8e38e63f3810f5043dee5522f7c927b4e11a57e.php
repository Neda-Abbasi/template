
<?php $__env->startSection('title', 'Staff'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>
                     
                     <?php if(isset($staff)): ?>
                     <?php echo e('ویرایش کارمند'); ?>


                     <?php else: ?>
                     <?php echo e('ثبت و راجستر کارمند'); ?>


                     <?php endif; ?>
                </h4>
                
            </div>
            <?php echo $__env->make('layouts.component.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <form class="" action="<?php echo e(isset($staff) ? route('staff.update', $staff): route('staff.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php if(isset($staff)): ?>
                    <?php echo method_field('PUT'); ?>
                <?php else: ?>
                    <?php echo method_field('POST'); ?>
                <?php endif; ?>
                
                <div class="form-row align-items-center">
                    <div class="col-3">
                        <label class="" for="inlineFormInput">نام </label>
                        <input type="text" class="form-control " id="inlineFormInput" name="name" value="<?php echo e(isset($staff) ? $staff->name: old('name')); ?>">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-3">
                        <label class="" for="inlineFormInput">تخلص </label>
                        <input type="text" class="form-control " id="inlineFormInput" name="last_name" value="<?php echo e(isset($staff) ? $staff->last_name: old('last_name')); ?>">
                        <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-3">
                        <label class="" for="fathername">نام پدر</label>
                        <input type="text" class="form-control " id="fathername" name="fathername" value="<?php echo e(isset($staff) ? $staff->fathername: old('fathername')); ?>">
                        <?php $__errorArgs = ['fathername'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-3">
                        <label class="" for="inlineFormInputGroup">شماره تماس</label>
                        <input type="tel" class="form-control " name="mobile"  value="<?php echo e(isset($staff) ? $staff->mobile: old('mobile')); ?>">
                        <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="col-2">
                        <label class="" for="inlineFormInputGroup">نوع کارمند</label>
                        <select class="form-control " name="type" id="type">
                            <option value="fixed" <?php if(isset($staff)): ?> <?php if($staff->type== 'fixed'): ?><?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>>معاش ثابت</option>
                            <option value="percentage" <?php if(isset($staff)): ?> <?php if($staff->type== 'percentage'): ?><?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>>فیصدی</option>
                            <option value="servant" <?php if(isset($staff)): ?> <?php if($staff->type== 'servant'): ?><?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>>خدمه</option>
                        </select>    
                        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-2">
                        <label class="" for="inlineFormInputGroup"> معاش</label>
                        <input type="number" step="0.1" class="form-control " id="salary" name="salary"  value="<?php echo e(isset($staff) ? $staff->salary: old('salary')); ?>">
                        <?php $__errorArgs = ['salary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-6">
                        <label class="" for="inlineFormInputGroup">آدرس</label>
                        <input type="text" class="form-control " name="address"  value="<?php echo e(isset($staff) ? $staff->address: old('address')); ?>">
                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    
                    <div class="col-2">
                        <label class="" for="inlineFormInputGroup">سند</label>
                        <input type="file" class="form-control " name="photo" >
                        <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <?php if(isset($staff)): ?>
                        <div class="col-12 col-sm-4 col-md-3 mt-3">
                            <label class="" for="inlineFormInputGroup"> </label>

                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" <?php if($staff->status == 1): ?><?php echo e('checked'); ?> <?php endif; ?> name="status" id="deposit" value="1">
                                <label class="form-check-label" for="deposit">
                                فعال
                                </label>
                            </div>
                            <div class="form-check  form-check-inline">
                                <input class="form-check-input" type="radio" <?php if($staff->status == 0): ?><?php echo e('checked'); ?> <?php endif; ?> name="status" id="withdraw" value="0">
                                <label class="form-check-label" for="withdraw">
                                غیرفعال
                                </label>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-row align-items-center mt-2 services">
                    <?php if(!isset($staff) ): ?>
                    <h4 >خدمات</h4>
                        <div class="col-12 col-offset-2 mt-2">
                            <table class="table table-sm table-striped table-bordered ">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">خدمات</th>
                                        <th scope="col">فیصدی</th>
                                    
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $c = 1; 
                                    ?>
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td scope="row"><?php echo e($c++); ?> </td>
                                        <td><?php echo e($obj->name); ?><input type="hidden" name="service[]" value="<?php echo e($obj->id); ?>" /></td>
                                        <td><input type="text" name="percentage[]" class=" form-control" style="padding: 0; margin:0; height:35px;" /></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </tbody>
                            </table>
                        </div>    
                    <?php endif; ?>   
                </div>
                <div class="form-row align-items-center mt-2">
                    <div class="col-1">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block <?php echo e(isset($staff) ?'f-primary':'f-secondary'); ?> text-center"> <?php echo e(isset($staff) ?'ویرایش':'ثبت'); ?></button>
                    </div>
                </div>
            </form>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagescript'); ?>
    <script src="<?php echo e(asset('/js/staff/create.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nethub Desktop\Documents\GitHub\Barber\resources\views/staff/create.blade.php ENDPATH**/ ?>