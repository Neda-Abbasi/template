
<?php $__env->startSection('title', 'Staff'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>
                     
                     <?php if(!isset($queueNumber)): ?>
                     <?php echo e('افزودن نوبت  '); ?>


                     <?php else: ?>
                     <?php echo e('ویرایش نوبت  '); ?>

                     <?php endif; ?>
                </h4>
                
                <?php 
                // dd($queue); 
                ?>
            </div>
            <?php echo $__env->make('layouts.component.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <form class="" action="<?php echo e(isset($queueNumber) ? route('queue_number.update', $queueNumber): route('queue_number.store')); ?>" method="POST" >
                <?php echo csrf_field(); ?>
                <?php if(isset($queueNumber)): ?>
                    <?php echo method_field('PUT'); ?>
                <?php else: ?>
                    <?php echo method_field('POST'); ?>
                <?php endif; ?>
                
                <div class="form-row align-items-center">
                <div class="col-4">
                        <label class="" for="customer">مشتری</label>
                        <input type="text" class="form-control "  id="customer" name="customer" value="<?php echo e(isset($queueNumber) ? $queueNumber->customer:''); ?>">
                    </div>
                   
                    <div class="col-6  col-sm-4">
                        <label class="" for="inlineFormInputGroup">کارمند </label>
                        <select class="form-control " name="staff1" id="staff1">
                            <option value="">انتخاب نمایید</option>
                            <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($staff->id); ?>"   <?php if(isset($queueNumber)): ?> <?php if($staff->id == $queueNumber->staff_id): ?><?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>><?php echo e($staff->name); ?> <?php echo e($staff->last_name); ?> </option>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>    
                        <?php $__errorArgs = ['staff'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  
                  

                    <div class="col-1">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block <?php echo e(isset($queueNumber) ?'f-primary':'f-secondary'); ?> text-center"> <?php echo e(isset($queueNumber) ?'ویرایش':'ثبت'); ?></button>
                    </div>
                </div>
            </form>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescript'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nethub Desktop\Documents\GitHub\Barber\resources\views/queue/create.blade.php ENDPATH**/ ?>