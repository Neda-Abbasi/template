<?php
ob_start();
	$dbhost = 'localhost';
	// $dbuser = 'root';
	$dbuser = env('DB_USERNAME');
	$dbpass = env('DB_PASSWORD');
	$dbname = env('DB_DATABASE');
	// $dbpass = 'Nethub_786';
	// $dbname = 'laravel_barber';
	// $path = "backup_sql/sqlD.sql";
   
	//test code
	EXPORT_TABLES($dbhost,$dbuser,$dbpass,$dbname,false,"MIS-backup-".date("d-m-Y-h-i-A").".sql");
	function EXPORT_TABLES($host,$user,$pass,$name,  $tables=false, $backup_name=false ){
	    $mysqli = new mysqli($host,$user,$pass,$name); $mysqli->select_db($name); $mysqli->query("SET NAMES 'utf8'");
	    $queryTables = $mysqli->query('SHOW TABLES'); while($row = $queryTables->fetch_row()) { $target_tables[] = $row[0]; }   if($tables !== false) { $target_tables = array_intersect( $target_tables, $tables); }

	    //setting headers
	    $content = (!isset($content) ?  '' : $content);
        $content.= 'SET FOREIGN_KEY_CHECKS=0;' . "\r\n";
        $content.= 'SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";' . "\r\n";
        $content.= 'SET AUTOCOMMIT=0;' . "\r\n";
        $content.= 'START TRANSACTION;' . "\r\n";
	    //setting headers

	    foreach($target_tables as $table){
	    	$query = "SELECT * FROM `$table`";
	        $result = $mysqli->query($query);  
	        $fields_amount=$result->field_count;  
	        $rows_num=$mysqli->affected_rows;    
	        $res = $mysqli->query('SHOW CREATE TABLE '.$table); 
	        $TableMLine=$res->fetch_row();

	        //to add create statement
	        $content.= "\n\n".$TableMLine[1].";\n\n";

	        for ($i = 0, $st_counter = 0; $i < $fields_amount;   $i++, $st_counter=0) {
	            while($row = $result->fetch_row())  { //when started (and every after 100 command cycle):
	                if ($st_counter%100 == 0 || $st_counter == 0 )  {$content .= "\nINSERT INTO `".$table."` VALUES";}
	                    $content .= "\n(";
	                    for($j=0; $j<$fields_amount; $j++)  { $row[$j] = str_replace("\n","\\n", addslashes($row[$j]) ); if (isset($row[$j])){$content .= '"'.$row[$j].'"' ; }else {$content .= '""';}     if ($j<($fields_amount-1)){$content.= ',';}      }
	                    $content .=")";
	                //every after 100 command cycle [or at last line] ....p.s. but should be inserted 1 cycle eariler
	                if ( (($st_counter+1)%100==0 && $st_counter!=0) || $st_counter+1==$rows_num) {$content .= ";";} else {$content .= ",";} $st_counter=$st_counter+1;
	            }
	        } $content .="\n\n\n";
	    }
	    
	    //setting footers
	    $content.= 'SET FOREIGN_KEY_CHECKS=1;' . "\r\n";
        $content.= 'COMMIT;' . "\r\n";
	    //setting footers

	    $backup_name = $backup_name ? $backup_name : $name."___(".date('H-i-s')."_".date('d-m-Y').")__rand".rand(1,11111111).".sql";
	    //test
		/*
		// $fp = fopen($path, "wb");
		$fp = fopen("backup_sql/sqlD.sql", "wb");
		fwrite($fp, $content);
		fclose($fp);
	    die();
	    */
	    //test

	    header('Content-Type: application/octet-stream');   
	    header("Content-Transfer-Encoding: Binary"); 
	    header("Content-disposition: attachment; filename=\"".$backup_name."\"");  
	    echo $content;
	    exit;
	}
?><?php /**PATH C:\Users\Nethub Desktop\Documents\GitHub\Barber\resources\views/backup.blade.php ENDPATH**/ ?>