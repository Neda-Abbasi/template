
<?php $__env->startSection('title', 'Bill'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>
                     
                     <?php if(isset($bill)): ?>
                     <?php echo e('ویرایش بل'); ?>

                     <?php else: ?>
                     <?php echo e('ثبت بل جدید'); ?>

                     <?php endif; ?>
                </h4>
                
            </div>
            <?php echo $__env->make('layouts.component.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 p-0">
                <div class="col-sm-12">
                    <h5>
                         
                         <?php if(!isset($queueNumber)): ?>
                         <?php echo e('افزودن نوبت  '); ?>

    
                         <?php else: ?>
                         <?php echo e('ویرایش نوبت  '); ?>

                         <?php endif; ?>
                    </h5>
                   
                </div>
                <?php echo $__env->make('layouts.component.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form class="" action="<?php echo e(isset($queueNumber) ? route('queue_number.update', $queueNumber): route('queue_number.store')); ?>" method="POST" >
                    <?php echo csrf_field(); ?>
                    <?php if(isset($queueNumber)): ?>
                        <?php echo method_field('PUT'); ?>
                    <?php else: ?>
                        <?php echo method_field('POST'); ?>
                    <?php endif; ?>
                    
                    <div class="form-row align-items-center">
                    <div class="col-4">
                            <label class="" for="customer">مشتری</label>
                            <input type="text" class="form-control "  id="customer" name="customer" value="<?php echo e(isset($queueNumber) ? $queueNumber->customer:''); ?>">
                            <input type="hidden" class="form-control "  name="source" value="bill">
                        </div>
                       
                        <div class="col-6  col-sm-4">
                            <label class="" for="inlineFormInputGroup">کارمند </label>
                            <select class="form-control " name="staff1" id="staff1">
                                <option value="">انتخاب نمایید</option>
                                <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($staff->id); ?>"   <?php if(isset($queueNumber)): ?> <?php if($staff->id == $queueNumber->staff_id): ?><?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>><?php echo e($staff->name); ?> <?php echo e($staff->last_name); ?> </option>    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>    
                            <?php $__errorArgs = ['staff'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="alert text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      
                        <div class="col-1">
                            <label class="" for="inlineFormInputGroup"><br></label>
                            <button type="submit" class="btn btn-block <?php echo e(isset($queueNumber) ?'f-primary':'f-secondary'); ?> text-center"> <?php echo e(isset($queueNumber) ?'ویرایش':'ثبت'); ?></button>
                        </div>
                    </div>
                </form>
              
            </div>

            <form class="" action="<?php echo e(isset($bill) ? route('bill.update', $bill): route('bill.store')); ?>" method="POST" style="border-top: 1px solid green;">
                <?php echo csrf_field(); ?>
                <?php if(isset($bill)): ?>
                    <?php echo method_field('PUT'); ?>
                <?php else: ?>
                    <?php echo method_field('POST'); ?>
                <?php endif; ?>
                
                <div class="form-row align-items-center">
                    <div class="col-6  col-sm-3">
                        <label class="" for="inlineFormInput">مشتری </label>
                        <input type="text" class="form-control " id="inlineFormInput" name="customer" value="<?php echo e(isset($bill) ? $bill->customer: old('customer')); ?>">
                        <?php $__errorArgs = ['customer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-6 col-sm-3">
                        <label class="" for="inlineFormInput">تاریخ </label>
                        <input type="date" class="form-control " id="inlineFormInput" name="bill_date" value="<?php echo e(isset($bill) ? $bill->bill_date: old('bill_date')); ?>">
                        <?php $__errorArgs = ['bill_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                </div>
                <div class="form-row align-items-center">
                    <hr>
                </div>
                <div class="form-row align-items-center pt-2" style="border-top: 1px solid green;">
                    <div class="col-6  col-sm-3">
                        <label class="" for="inlineFormInputGroup">کارمند </label>
                        <select class="form-control " name="staff" id="staff">
                            <option value="">انتخاب نمایید</option>
                            <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($staff->id); ?>" ><?php echo e($staff->name); ?> <?php echo e($staff->last_name); ?> </option>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>    
                        <?php $__errorArgs = ['staff'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-6  col-sm-2">
                        <label class="" for="inlineFormInputGroup">خدمات </label>
                        <select class="form-control " name="service" id="service">
                            <option value="">انتخاب نمایید</option>
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($service->id); ?>" data-cost="<?php echo e($service->cost); ?>"><?php echo e($service->name); ?> </option>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>    
                        <?php $__errorArgs = ['service'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-4  col-sm-2">
                        <label class="" for="cost">تعداد </label>
                        <input type="text" class="form-control " id="qty" name="qty" value="1" >
                    </div>
                    <div class="col-4  col-sm-2">
                        <label class="" for="cost">نرخ </label>
                        <input type="text" class="form-control " readonly id="cost" name="cost" >
                    </div>
                    <div class="col-4  col-sm-2">
                        <label class="" for="cost">جمله </label>
                        <input type="text" class="form-control " readonly id="total" name="total" >
                    </div>


                    <div class="col-3  col-sm-1">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="button" class="btn btn-block f-forth text-center jsAddGood"> <i class="fa fa-plus"></i></button>
                    </div>


                </div>
                <div class="form-row align-items-center mt-2">
                    <table class="table table-bordered jsGoodsTable table-sm">
                        <thead>
                            <tr>
                                <th>خدمات</th>
                                <th>کارمند</th>
                                <th>تعداد</th>
                                <th>نرخ</th>
                                <th>جمله</th>
                                <th>عمل</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                    <input type="hidden" class="" name="hfGoodList" value="" id="hfGoodList" placeholder="json enc" />
                </div>



                <div class="form-row align-items-center">
                    <hr>
                </div>
                <div class="form-row align-items-center pt-2" style="border-top: 1px solid rgb(228, 7, 7);">
                    <div class="col-6  col-sm-3">
                        <label class="" for="inlineFormInputGroup">محصولات </label>
                        <select class="form-control " name="product" id="product">
                            <option value="">انتخاب نمایید</option>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($product->id); ?>" data-available="<?php echo e($product->qty); ?>"  data-sell="<?php echo e($product->sell); ?>" data-purchase="<?php echo e($product->purchase); ?>"><?php echo e($product->name); ?></option>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>    
                        <?php $__errorArgs = ['product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-4  col-sm-2">
                        <label class="" for="cost">موجود </label>
                        <input type="text" class="form-control " readonly id="available" name="available" >
                    </div>
                    
                    <div class="col-4  col-sm-2">
                        <label class="" for="cost">تعداد </label>
                        <input type="text" class="form-control " id="p_qty" name="p_qty" value="1" >
                    </div>
                    <div class="col-4  col-sm-2">
                        <label class="" for="cost">نرخ </label>
                        <input type="text" class="form-control " readonly id="p_cost" name="p_cost" >
                        <input type="hidden" class="form-control " readonly id="purchase" name="purchase" >
                    </div>
                    <div class="col-4  col-sm-2">
                        <label class="" for="cost">جمله </label>
                        <input type="text" class="form-control " readonly id="p_total" name="p_total" >
                    </div>

                    <div class="col-3  col-sm-1">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="button" class="btn btn-block f-third text-center jsAddProduct"> <i class="fa fa-plus"></i></button>
                    </div>

                </div>
                <div class="form-row align-items-center mt-2">
                    <table class="table table-bordered jsProductsTable table-sm">
                        <thead>
                            <tr>
                                <th>محصول</th>
                                <th>موجود</th>
                                <th>تعداد</th>
                                <th>نرخ</th>
                                <th>جمله</th>
                                <th>عمل</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                    <input type="hidden" class="" name="hfProductList" value="" id="hfProductList" placeholder="json enc" />

                    <div class="col-4  col-sm-2">
                        <label class="" for="cost">مجموع </label>
                        <input type="number" class="form-control " readonly id="grand_total" name="grand_total" >
                        <?php $__errorArgs = ['grand_total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-4  col-sm-2">
                        <label class="" for="cost">تخفیف </label>
                        <input type="number" class="form-control " id="discount" name="discount" value="0">
                    </div>
                    <div class="col-4  col-sm-2">
                        <label class="" for="cost">قابل پرداخت </label>
                        <input type="number" class="form-control " readonly id="payable" name="payable" >
                    </div>

                    <div class="col-4 col-sm-1">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block <?php echo e(isset($service) ?'f-primary':'f-secondary'); ?> text-center"  onclick="return getData()">  <?php echo e(isset($service) ?' ثبت':'ویرایش'); ?></button>
                    </div>
                </div>
            </form>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescript'); ?>
    <script src="<?php echo e(asset('/js/bill/create.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nethub Desktop\Documents\GitHub\Barber\resources\views/bill/create.blade.php ENDPATH**/ ?>