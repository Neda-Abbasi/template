
<?php $__env->startSection('title', 'Staff'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">

            <?php echo $__env->make('layouts.component.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <h4 class="card-title">لست کارمندان</h4>

            <hr>
            <table class="table table-sm table-striped table-bordered" id="datatable">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">نام</th>
                        <th scope="col">نام پدر</th>
                        <th scope="col">شماره تماس</th>
                        <th scope="col">نوع قرارداد</th>
                        <th scope="col">عاید</th>
                        <th scope="col">برداشت</th>
                        <th scope="col">حالت</th>

                        <th scope="col">عمل</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $c = 1; 
                    $total =0; 
                    $gtotal =0; 
                    $paid =0; 
                    $gpaid =0; 
                    ?>
                    <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    <tr>
                        <td scope="row"><?php echo e($c++); ?> </td>
                        <td><a href="<?php echo e((isset($staff->file) && ($staff->file != '')) ? $staff->file : '#'); ?>" target="_blank"><?php echo e($staff->name); ?> <?php echo e($staff->last_name); ?></a></td>
                        <td><?php echo e($staff->fathername); ?> </td>
                        <td><?php echo e($staff->mobile); ?></td>
                        <td><?php if($staff->type=='fixed'): ?> <?php echo e('معاش ثابت'); ?>

                            <?php elseif($staff->type=='percentage'): ?><?php echo e('فیصدی'); ?>

                            <?php else: ?> <?php echo e('خدمه'); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($staff->type=='percentage'): ?>
                        <?php $percentages = app\Http\controllers\StaffController::getStaffPercentage($staff->id); ?>
                            
                            <?php echo e($percentages[0]->total); ?>

                            <?php endif; ?>
                            <?php $percentages=null; ?>
                            
                        </td>
                        <td><?php $__currentLoopData = $staff->staff_payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <?php
                                    $paid += $obj->amount ;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        <?php echo e($paid); ?>

                        <?php $paid = 0; ?>
                        </td>
                        <td><?php if($staff->status == 1): ?> <?php echo e('فعال'); ?> <?php else: ?><?php echo e('غیر فعال'); ?> <?php endif; ?></td>

                        <td><a href="<?php echo e(route('staff.edit', $staff)); ?>" title="ویرایش" class="btn btn-success btn-sm"><i class="fa fa-edit"></i></a>  
                        <?php if($staff->type == 'percentage'): ?>
                            <a href="<?php echo e(route('staff.show', $staff)); ?>" title="خدمات" class="btn f-third btn-sm"><i class="fa fa-bars"></i></a>  
                        <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
            </table>
            
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescript'); ?>
    <script src="/js/client/index.js"></script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nethub Desktop\Documents\GitHub\Barber\resources\views/staff/index.blade.php ENDPATH**/ ?>