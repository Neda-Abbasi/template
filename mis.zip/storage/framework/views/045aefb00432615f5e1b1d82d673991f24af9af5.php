<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Queue Bill</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.6 -->
    <link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>">
    <!-- Font Awesome -->
    
    
    <link rel="stylesheet" href="<?php echo e(asset('/css/print.css')); ?>">
</head>
<script type="text/javascript">
    window.onafterprint = back;

    function back() {
        // window.history.back(); //It goes one step back which again prompts for form submission
        // window.history.go(-2);
        document.location.href = '/bill/create';
    }
</script>

<body onload="window.print();">
    <!--
<body>-->
    <div class="wrapper">
        <!-- Main content -->
        <section class="invoice">
            <!-- /.row -->
            <div class="print-box jsBillPrintBox cook-bill">
                <table class="print-tbl restaurant-specs" border="1">
                    <tbody>
                        <tr>
                            <td class="sbold text-center"><img src="<?php echo e(asset('img/logo.jpg')); ?>" width="80%"></td>
                        </tr>

                    </tbody>
                </table>
                <br>
                <table class="print-tbl" border="1">
                    <tbody class="jsBillItems" dir="rtl">

                        <tr>
                            <td colspan="5">اسم کارمند : <span class="jsOrderType"><?php echo e($bill->staff->name); ?></span> <br>اسم مشتری : <span class="jsOrderType"><?php echo e($bill->customer); ?></span></td>
                        </tr>
                        <tr>
                        <tr>
                            <td class="sbold text-center" style="height: 200px;">
                                <h1 style="font-size:200px"><?php echo e($bill->queue_number_id); ?></h1>
                            </td>
                        </tr>

                    </tbody>
                </table>

                <table class="print-tbl" dir="rtl">
                    <tbody>

                        <tr>
                            <td> تاریخ : <span class="jsBillDate"><?php echo e(date('d-m-Y', strtotime($bill->created_at))); ?></span></td>
                            <td> ساعت : <span class="jsBillDate" dir="ltr"><?php echo e(date('h : i ', strtotime($bill->created_at))); ?></span></td>
                        </tr>
                        <tr>
                            <td  colspan="4" style="text-align: center">
                                شماره تماس: 0780621421  
                            </td>
                        </tr>
                        <tr>
                            <td class="dotted full" colspan="4">
                                <hr />
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- ./wrapper -->
</body>
</html><?php /**PATH C:\Users\Nethub Desktop\Documents\GitHub\Barber\resources\views/receipt/queue_bill.blade.php ENDPATH**/ ?>