
<?php $__env->startSection('title', 'Sell Report'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>
                    راپور فروشات
                </h4>
                <?php if($errors->any()): ?>
                    <?php echo e(implode('', $errors->all('<div>:message</div>'))); ?>

                <?php endif; ?>
            </div>

            <?php 
            // dd($sells);
            ?>
            <?php echo $__env->make('layouts.component.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <form class="" action="<?php echo e(route('report.getSell')); ?>" method="POST" >
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                
                <div class="form-row align-items-center">
                    
                    <div class="col-5">
                        <label class="" for="inlineFormInput">از تاریخ</label>
                        <input type="date" class="form-control " name="from">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  
                    <div class="col-5">
                        <label class="" for="inlineFormInputGroup">الی تاریخ</label>
                        <input type="date" class="form-control " name="to">
                        <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="alert text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="col-2">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block f-primary text-center"> ارسال</button>
                    </div>
                </div>
                

            </form>
            <?php if(isset($sells)): ?>
                
                <table class="table table-sm table-striped table-bordered display compact" id="datatable-report">
                    <thead>
                        <tr>
                            <th scope="col">تاریخ </th>
                            <th scope="col"> بل</th>
                            <th scope="col"> محصول</th>
                            <th scope="col">تعداد</th>
                            <th scope="col">خرید</th>
                            <th scope="col">فروش</th>
                            <th scope="col">مفاد</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $gtotal = 0;
                        $total = 0;
                        $gsell = 0;
                        $gpurchase = 0;
                        $profit = 0;
                        ?>
                        <?php if(isset($sells)): ?>
                            <?php $__currentLoopData = $sells; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(date('d-m-Y', strtotime($sel->created_at))); ?></td>
                            <td><?php echo e($sel->bill_id); ?></td>
                            <td><?php echo e($sel->product->name); ?></td>
                            <td><?php echo e($sel->qty); ?></td>
                            <td><?php echo e($sel->purchase); ?></td>
                            <td><?php echo e($sel->sell); ?> </td>
                            <td><?php echo e($profit = ($sel->qty * $sel->sell) - ($sel->qty * $sel->purchase)); ?> </td>
                        </tr>
                        <?php 
                        
                        $gsell += $sel->sell;
                        $gpurchase += $sel->purchase;
                        $gtotal += $profit;
                        
                        ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th></th>
                            <th></th>
                            <th>جمله</th>
                            <th></th>
                            <th><?php echo e($gpurchase); ?></th>
                            <th><?php echo e($gsell); ?></th>
                            <th><?php echo e($gtotal); ?></th>
                            <!-- <th><?php echo e($discount); ?></th> -->
                        </tr>
                    </tfoot>
                </table>
            <?php endif; ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nethub Desktop\Documents\GitHub\Barber\resources\views/report/sell.blade.php ENDPATH**/ ?>