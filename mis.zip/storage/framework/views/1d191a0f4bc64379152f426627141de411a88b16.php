
<?php $__env->startSection('title', 'Bills'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">

            <?php echo $__env->make('layouts.component.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <h4 class="card-title">لست بل ها</h4>

            <hr>
            <table class="table table-sm table-striped table-bordered" id="datatable">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">بل</th>
                        <th scope="col">مشتری</th>
                        <th scope="col">جمله</th>
                        <th scope="col">تخفیف</th>
                        <th scope="col">تاریخ</th>
                        <th scope="col">عمل</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $c = 1 ?>
                    <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    <tr>
                        <td scope="row"><?php echo e($c++); ?> </td>
                        <td><?php echo e($bill->id); ?></a></td>
                        <td><?php echo e($bill->customer); ?> </td>
                        <td><?php echo e($bill->total); ?> </td>
                        <td><?php echo e($bill->discount); ?></td>
                        <td><?php echo e($bill->bill_date); ?></td>
                        <td>
                            <a href="<?php echo e(route('bill.edit', $bill)); ?>" title="ویرایش" class="btn btn-success btn-sm d-inline"><i class="fa fa-edit"></i></a>  
                            <a href="<?php echo e(route('bill.show', $bill)); ?>" title="رسید" class="btn f-third btn-sm d-inline"> <i class="fa fa-file-pdf"></i></a>

                            

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
            </table>
            

        </div>



    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nethub Desktop\Documents\GitHub\Barber\resources\views/bill/index.blade.php ENDPATH**/ ?>