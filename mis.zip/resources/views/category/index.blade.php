@extends('app')
@section('title', 'Expense Category')

@section('content')
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>

                    کتگوری مصارف
                </h4>
                {{-- @php dd($saraf); @endphp --}}
                @if ($errors->any())
                <div class="text-center">
                    @foreach ($errors->all() as $error)
                    <span class="text-danger"> {{ $error }} </span><br>
                    @endforeach
                </div>
                @endif
            </div>
            @include('layouts.component.alert')
            <form action="{{ isset($category) ? route('category.update', $category->id) : route('category.store') }}" method="post" enctype="multipart/form-data">
                @csrf
                @if(isset($category))
                @method('PUT')
                @else
                @method('POST')
                @endif

                <div class="form-row align-items-center">
                    <div class="col-3">
                        <label class="" for="inlineFormInput">نام کتگوری</label>
                        <input type="text" class="form-control " id="inlineFormInput" name="name" value="{{isset($category) ? $category->name: old('name')}}">
                        @error('name')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    @if(isset($category))
                    <div class="col-12 col-sm-4 col-md-3 mt-3">
                        <label class="" for="inlineFormInputGroup"> </label>

                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" @if($category->status == 1){{'checked'}} @endif name="status" id="deposit" value="1">
                            <label class="form-check-label" for="deposit">
                                فعال
                            </label>
                        </div>
                        <div class="form-check  form-check-inline">
                            <input class="form-check-input" type="radio" @if($category->status == 0){{'checked'}} @endif name="status" id="withdraw" value="0">
                            <label class="form-check-label" for="withdraw">
                                غیرفعال
                            </label>
                        </div>
                    </div>
                    @endif
                    <div class="col-1">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block {{isset($category) ?'f-primary':'f-secondary' }} text-center"> {{isset($category) ?'ویرایش':'ثبت' }}</button>
                    </div>
                </div>
            </form>

            <h5 class="card-title">لست صرافان</h5>

            <hr>
            <table class="table table-sm table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">نام</th>
                        <th scope="col">حالت</th>
                        <th scope="col">عمل</th>
                    </tr>
                </thead>
                <tbody>
                    @php $c = 1 @endphp
                    @foreach ($categories as $category)

                    <tr>
                        <th scope="row">{{$c++}} </th>
                        <td>{{$category->name}}</td>
                        <td>@if($category->status == 1) {{'فعال'}} @else{{'غیر فعال'}} @endif</td>
                        <td><a href="{{route('category.edit', $category)}}" title="ویرایش" class="btn btn-success btn-sm"><i class="fa fa-edit"></i></a>
                        </td>
                    </tr>
                    @endforeach

                </tbody>
            </table>


        </div>



    </div>
</div>
@endsection