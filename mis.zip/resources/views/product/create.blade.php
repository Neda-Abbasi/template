@extends('app')
@section('title', 'Product')

@section('content')
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>
                     
                     @if (isset($product))
                     {{'ویرایش محصول'}}

                     @else
                     {{'ثبت و راجستر محصول'}}

                     @endif
                </h4>
                {{-- @if($errors->any())
                    {{ implode('', $errors->all('<div>:message</div>')) }}
                @endif --}}
            </div>
            @include('layouts.component.alert')
            <form class="" action="{{isset($product) ? route('product.update', $product): route('product.store')}}" method="POST" enctype="multipart/form-data">
                @csrf
                @if(isset($product))
                    @method('PUT')
                @else
                    @method('POST')
                @endif
                
                <div class="form-row align-items-center">
                    <div class="col-3">
                        <label class="" for="inlineFormInput">نام محصول</label>
                        <input type="text" class="form-control " id="inlineFormInput" name="name" value="{{isset($product) ? $product->name: old('name')}}">
                        @error('name')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-3">
                        <label class="" for="inlineFormInput">قیمت خرید </label>
                        <input type="number" class="form-control " id="inlineFormInput" name="purchase" value="{{isset($product) ? $product->purchase: old('purchase')}}">
                        @error('purchase')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-3">
                        <label class="" for="inlineFormInput">قیمت فروش </label>
                        <input type="number" class="form-control " id="inlineFormInput" name="sell" value="{{isset($product) ? $product->sell: old('sell')}}">
                        @error('sell')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    
                    <div class="col-3">
                        <label class="" for="inlineFormInputGroup"> تعداد</label>
                        <input type="number" class="form-control " id="qty" name="qty"  value="{{isset($product) ? $product->qty: old('qty')}}">
                        @error('qty')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    
                    <div class="col-3">
                        <label class="" for="inlineFormInputGroup"> حداقل موجود</label>
                        <input type="number" class="form-control " id="min_stock" name="min_stock"  value="{{isset($product) ? $product->min_stock: old('min_stock')}}">
                        @error('min_stock')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                  
                    <div class="col-2">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block {{isset($product) ?'f-primary':'f-secondary' }} text-center"> {{isset($product) ?'ویرایش':'ثبت' }}</button>
                    </div>
                </div>
            </form>
        </div>

    </div>
</div>
@endsection
