@extends('app')
@section('title', 'Discount Report')

@section('content')
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>
                    راپور تخفیف
                </h4>
                @if($errors->any())
                    {{ implode('', $errors->all('<div>:message</div>')) }}
                @endif
            </div>

            @php 
            // dd($sells);
            @endphp
            @include('layouts.component.alert')
            <form class="" action="{{ route('report.getDiscount')}}" method="POST" >
                @csrf
                @method('POST')
                
                <div class="form-row align-items-center">
                    
                    <div class="col-5">
                        <label class="" for="inlineFormInput">از تاریخ</label>
                        <input type="date" class="form-control " name="from">
                        @error('name')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                  
                    <div class="col-5">
                        <label class="" for="inlineFormInputGroup">الی تاریخ</label>
                        <input type="date" class="form-control " name="to">
                        @error('to')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    
                    <div class="col-2">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block f-primary text-center"> ارسال</button>
                    </div>
                </div>
                

            </form>
            @if(isset($bills))
                
                <table class="table table-sm table-striped table-bordered display compact" id="datatable-report">
                    <thead>
                        <tr>
                            <th scope="col">تاریخ </th>
                            <th scope="col"> بل</th>
                            
                            <th scope="col">جمله</th>
                            <th scope="col">تخفیف</th>
                            <th scope="col">قابل پرداخت</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php 
                        $gtotal = 0;
                        $disc = 0;
                        $total = 0;
                        @endphp
                        @if(isset($bills))
                            @foreach ($bills as $bill)
                        <tr>
                            <td>{{ date('d-m-Y', strtotime($bill->created_at)) }}</td>
                            <td>{{$bill->id}}</td>
                            <td>{{$bill->total}}</td>
                            <td>{{$bill->discount}}</td>
                            <td>{{$total = $bill->total - $bill->discount}}</td>
                            
                        </tr>
                        @php $gtotal +=$total;
                            $disc += $bill->discount;
                        @endphp

                            @endforeach
                        @endif
                    </tbody>
                    <tfoot>
                        <tr>
                            <th></th>
                            <th></th>
                            <th>جمله</th>
                            <th>{{$disc}}</th>
                            <th>{{$gtotal}}</th>
                        </tr>
                    </tfoot>
                </table>
            @endif

        </div>
    </div>
</div>
@endsection