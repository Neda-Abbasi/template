@extends('app')
@section('title', 'Profit and Loss Report')

@section('content')
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>
                    راپور مفاد و ضرر
                </h4>
                @if($errors->any())
                {{ implode('', $errors->all('<div>:message</div>')) }}
                @endif
            </div>

            @php
            // dd($logs);
            @endphp
            @include('layouts.component.alert')
            <form class="" action="{{ route('report.getpl') }}" method="POST">
                @csrf
                @method('POST')

                <div class="form-row align-items-center">

                    <div class="col-5">
                        <label class="" for="inlineFormInput">از تاریخ</label>
                        <input type="date" class="form-control " name="from">
                        @error('name')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>

                    <div class="col-5">
                        <label class="" for="inlineFormInputGroup">الی تاریخ</label>
                        <input type="date" class="form-control " name="to">
                        @error('to')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>

                    <div class="col-1">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block f-primary text-center"> ارسال</button>
                    </div>
                </div>


            </form>

          
            <table class="print-tbl w-50"  border="1" >
					<tbody class="jsBillItems" dir="rtl">
						
                    @if(!isset($discount)) @php $discount = 0; @endphp @endif
						<tr>
							<th class="text-right p-1" colspan="2">عواید : </th>
							<td class="text-right p-1 jsSubTotal" colspan="">@if(isset($income)) {{$income}} @else @php $income = 0; @endphp @endif</td>
						</tr>
					
						<tr>
							<th class="text-right p-1" colspan="2">مصارف : </th>
							<td class="text-right p-1 jsSubTotal" colspan="">@if(isset($expense)) {{$expense}} @else @php $expense = 0; @endphp @endif</td>
						</tr>
					
						<tr>
							<th class="text-right p-1" colspan="2">مفاد محصول : </th>
							<td class="text-right p-1 jsSubTotal" colspan="">@if(isset($profit)) {{$profit}} @else @php $profit = 0; @endphp @endif</td>
						</tr>
					
						<tr>
							<th class="text-right p-1" colspan="2">تخفیف: </th>
							<td class="text-right p-1 jsSubTotal"colspan="2">@if(isset($discount)) {{$discount}} @endif</td>
						</tr>
					
						<tr>
							<th class="text-right p-1" colspan="2">پرداختی کارمندان: </th>
							<td class="text-right p-1 jsSubTotal"colspan="3">@if(isset($payment)) {{$payment}} @else @php $payment = 0; @endphp @endif</td>
						</tr>
						<tr>
							<th class="text-right p-1" colspan="2"> بلانس: </th>
							<td class="text-right p-1 jsSubTotal"colspan="3">{{$income + $profit - $expense - $discount - $payment}}</td>
						</tr>
						
					</tbody>
				</table>

        </div>

    </div>
</div>
@endsection