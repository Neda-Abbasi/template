@extends('app')
@section('title', 'Sell Report')

@section('content')
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>
                    راپور فروشات
                </h4>
                @if($errors->any())
                    {{ implode('', $errors->all('<div>:message</div>')) }}
                @endif
            </div>

            @php 
            // dd($sells);
            @endphp
            @include('layouts.component.alert')
            <form class="" action="{{ route('report.getSell')}}" method="POST" >
                @csrf
                @method('POST')
                
                <div class="form-row align-items-center">
                    
                    <div class="col-5">
                        <label class="" for="inlineFormInput">از تاریخ</label>
                        <input type="date" class="form-control " name="from">
                        @error('name')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                  
                    <div class="col-5">
                        <label class="" for="inlineFormInputGroup">الی تاریخ</label>
                        <input type="date" class="form-control " name="to">
                        @error('to')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    
                    <div class="col-2">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block f-primary text-center"> ارسال</button>
                    </div>
                </div>
                

            </form>
            @if(isset($sells))
                
                <table class="table table-sm table-striped table-bordered display compact" id="datatable-report">
                    <thead>
                        <tr>
                            <th scope="col">تاریخ </th>
                            <th scope="col"> بل</th>
                            <th scope="col"> محصول</th>
                            <th scope="col">تعداد</th>
                            <th scope="col">خرید</th>
                            <th scope="col">فروش</th>
                            <th scope="col">مفاد</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php 
                        $gtotal = 0;
                        $total = 0;
                        $gsell = 0;
                        $gpurchase = 0;
                        $profit = 0;
                        @endphp
                        @if(isset($sells))
                            @foreach ($sells as $sel)
                        <tr>
                            <td>{{ date('d-m-Y', strtotime($sel->created_at)) }}</td>
                            <td>{{$sel->bill_id}}</td>
                            <td>{{$sel->product->name}}</td>
                            <td>{{$sel->qty}}</td>
                            <td>{{$sel->purchase}}</td>
                            <td>{{$sel->sell}} </td>
                            <td>{{$profit = ($sel->qty * $sel->sell) - ($sel->qty * $sel->purchase) }} </td>
                        </tr>
                        @php 
                        
                        $gsell += $sel->sell;
                        $gpurchase += $sel->purchase;
                        $gtotal += $profit;
                        
                        @endphp

                            @endforeach
                        @endif
                    </tbody>
                    <tfoot>
                        <tr>
                            <th></th>
                            <th></th>
                            <th>جمله</th>
                            <th></th>
                            <th>{{$gpurchase}}</th>
                            <th>{{$gsell}}</th>
                            <th>{{$gtotal}}</th>
                            <!-- <th>{{$discount}}</th> -->
                        </tr>
                    </tfoot>
                </table>
            @endif

        </div>
    </div>
</div>
@endsection