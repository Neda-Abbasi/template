@extends('app')
@section('title', 'Staff Performance')

@section('content')
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>
                    راپور کارمندان
                </h4>
                @if($errors->any())
                    {{ implode('', $errors->all('<div>:message</div>')) }}
                @endif
            </div>

            @php 
            // dd($logs);
            @endphp
            @include('layouts.component.alert')
            <form class="" action="{{ route('report.getStaff') }}" method="POST" >
                @csrf
                @method('POST')
                
                <div class="form-row align-items-center">
                    <div class="col-3">
                        <label class="" for="inlineFormInputGroup">کارمند </label>
                        <select class="form-control select2" name="staff" id="staff">
                            <option value="all">همه</option>
                            @foreach ($staffs as $staff)
                                <option value="{{$staff->id}}" >{{$staff->name}} {{$staff->last_name}} </option>    
                            @endforeach
                        </select>    
                        @error('from')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-4">
                        <label class="" for="inlineFormInput">از تاریخ</label>
                        <input type="date" class="form-control " name="from">
                        @error('name')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                  
                    <div class="col-4">
                        <label class="" for="inlineFormInputGroup">الی تاریخ</label>
                        <input type="date" class="form-control " name="to">
                        @error('to')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    
                    <div class="col-1">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block f-primary text-center"> ارسال</button>
                    </div>
                </div>
                

            </form>
            @if(isset($logs))
                
                <table class="table table-sm table-striped table-bordered display compact" id="datatable-report">
                    <thead>
                        <tr>
                            <th scope="col">تاریخ </th>
                            <th scope="col">بل </th>
                            <th scope="col"> کارمند</th>
                            {{-- <th scope="col"> مشتری</th> --}}
                            <th scope="col"> خدمات</th>
                            <th scope="col"> نرخ</th>
                            <th scope="col"> فیصدی</th>
                            <th scope="col">تعداد </th>
                            <th scope="col"> جمله</th>
                            <th scope="col"> فیصدی</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        @php 
                        $gtotal = 0;
                        $gper = 0;
                        $total = 0;
                        $perc = 0;
                        @endphp
                        @if(isset($logs))
                            @foreach ($logs as $log)
                        <tr>
                            <td>{{ date('d-m-Y', strtotime($log->created_at)) }}</td>
                            <td>{{$log->bill->id}}</td>
                            <td>{{$log->staff->name}}</td>
                            {{-- <td>{{$log->bill->customer}}</td> --}}
                            <td>{{$log->service->name}}</td>
                            <td>{{$log->cost}}</td>
                            <td>{{$log->percentage_amount}}</td>
                            <td>{{$log->qty}}</td>
                            <td>{{$total = $log->cost * $log->qty}} </td>
                            <td>    
                            {{-- <td>{{$per = ($total / 100) * $log->staff->percentage}}  --}}
                                
                                {{$perc = $total*$log->percentage_amount/100}}
                            </td>
                        </tr>
                            @php 
                            $gtotal +=$total;
                            $gper +=$perc;
                            @endphp
                            @endforeach
                        @endif
                    </tbody>
                    <tfoot>
                        <tr>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th>جمله</th>
                            <th>{{$gtotal}}</th>
                            <th>{{$gper}}</th>
                        </tr>
                    </tfoot>
                </table>
            @endif

        </div>



    </div>
</div>
@endsection