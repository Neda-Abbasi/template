@extends('app')
@section('title', 'Expense Report')

@section('content')
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>
                    راپور مصارف
                </h4>
                @if($errors->any())
                    {{ implode('', $errors->all('<div>:message</div>')) }}
                @endif
            </div>

            @php 
            // dd($logs);
            @endphp
            @include('layouts.component.alert')
            <form class="" action="{{ route('report.getExpense')}}" method="POST" >
                @csrf
                @method('POST')
                
                <div class="form-row align-items-center">
                    <div class="col-3">
                        <label class="" for="inlineFormInputGroup">کتگوری </label>
                        <select class="form-control " name="category" id="category">
                            <option value="all">همه</option>
                            @foreach ($categories as $category)
                                <option value="{{$category->id}}" >{{$category->name}} </option>    
                            @endforeach
                        </select>    
                        @error('from')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-4">
                        <label class="" for="inlineFormInput">از تاریخ</label>
                        <input type="date" class="form-control " name="from">
                        @error('name')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                  
                    <div class="col-4">
                        <label class="" for="inlineFormInputGroup">الی تاریخ</label>
                        <input type="date" class="form-control " name="to">
                        @error('to')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    
                    <div class="col-1">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block f-primary text-center"> ارسال</button>
                    </div>
                </div>
                

            </form>
            @if(isset($logs))
                
                <table class="table table-sm table-striped table-bordered display compact" id="datatable-report">
                    <thead>
                        <tr>
                            <th scope="col">تاریخ </th>
                            <th scope="col"> کتگوری</th>
                            <th scope="col"> تفصیلات</th>
                            <th scope="col">مبلغ</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php 
                        // dd($logs)
                        $withdraw = 0;
                        $deposit = 0;
                        $total = 0;
                        @endphp
                        @if(isset($logs))

                            @foreach ($logs as $log)
                            
                        <tr>
                            <td>{{ date('d-m-Y', strtotime($log->created_at)) }}</td>
                            <td>{{$log->expense_category->name}}</td>
                            <td>{{$log->description}}</td>
                            <td>{{$log->amount}} </td>
                        </tr>
                        @php $total +=$log->amount; @endphp

                            @endforeach
                        @endif
                    </tbody>
                    <tfoot>
                        <tr>
                            <th></th>
                            <th></th>
                            <th>جمله</th>
                            <th>{{$total}}</th>
                        </tr>
                    </tfoot>
                </table>
            @endif

        </div>
    </div>
</div>
@endsection