<!doctype html>
<html class="no-js" lang="">
    @include('layouts.header')

    {{-- <body class="rtl persianumber" style="overflow:hidden;"> --}}
<body class="rtl " style="overflow:hidden;">

    <div class="bmd-layout-container bmd-drawer-f-l avam-container animated bmd-drawer-in">
        <header class="bmd-layout-header ">
            <div class="navbar navbar-light bg-faded animate__animated ">
                <button class="navbar-toggler animate__animated animate__wobble animate__delay-2s" type="button"
                    data-toggle="drawer" data-target="#dw-s1">
                    <span class="navbar-toggler-icon"></span>
                    <!-- <i class="material-Animation">menu</i> -->
                </button>
                <ul class="nav navbar-nav ">
                    <li class="nav-item mr-2">
                        <a href="{{route('bill.create')}}"> بل جدید</a>
                    </li>
                    <li class="nav-item mr-2">
                        <a href="{{route('service.index')}}"> ثبت خدمات</a>
                    </li>
                    <li class="nav-item mr-2">
                        <a href="{{route('staff.create')}}"> ثبت کارمند</a>
                    </li>
                    <li class="nav-item mr-2">
                        <a href="{{route('expense.index')}}">  درج مصرف</a>
                    </li>
                    
                </ul>
                <ul class="nav navbar-nav ">
                    
                    <li class="nav-item d-none">
                        <div class="dropdown">
                            <button class="btn  dropdown-toggle m-0" type="button" id="dropdownMenu3"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="far fa-bell  fa-lg "></i><span
                                    class="badge badge-pill badge-warning animate__animated animate__flash animate__repeat-3 animate__slower animate__delay-2s">5</span>
                            </button>
                            <div aria-labelledby="dropdownMenu2"
                                class="dropdown-menu dropdown-menu-right dropdown-menu dropdown-menu-right-lg">
                                <span class="dropdown-item dropdown-header">15 Notifications</span>
                                <div class="dropdown-divider"></div>
                               
                                <div class="dropdown-divider"></div>
                                <a href="#" class="dropdown-item">
                                    <i class="far fa-file c-main mr-2"></i> 3 new reports
                                    <span class="float-right-rtl text-muted text-sm">2 days</span>
                                </a>
                                <div class="dropdown-divider"></div>
                                <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a>
                            </div>
                        </div>
                    </li>
                    <li class="nav-item d-none"> <img src="./img/user-profile.jpg" alt="..."
                            class="rounded-circle screen-user-profile"></li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <button class="btn  dropdown-toggle m-0" type="button" id="dropdownMenu4"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                {{auth()->user()->name}}
                            </button>
                            <div aria-labelledby="dropdownMenu4"
                                class="dropdown-menu dropdown-menu-right dropdown-menu dropdown-menu-right"
                                aria-labelledby="dropdownMenu2">
                                <a class="dropdown-item" href="{{route('profile.index')}}" ><i
                                    class="far fa-user fa-sm c-main mr-2"></i>تغیر رمز</a>
                                <button onclick="dark()" class="dropdown-item" type="button"><i
                                        class="fas fa-moon fa-sm c-main mr-2"></i>Dark Mode</button>
                            
                                <a class="dropdown-item" href="{{route('logout')}}" ><i
                                            class="fas fa-sign-out-alt c-main fa-sm mr-2"></i>خروج</a>
                            </div>
                        </div>
                    </li>
        
        
                </ul>
            </div>
        </header>
        @include('layouts.nav')

        
        <main class="bmd-layout-content">
           @yield('content')
        </main>
    </div>

    </div>
    @include('layouts.footer')
    
    @yield('pagescript')

    <script src="{{asset('/js/custom-script.js')}}"></script>
</body>

</html>