

	<script src="{{asset('/js/vendor/modernizr.js')}}"></script>
	<script src="{{asset('/js/jquery-3.2.1.min.js')}}"></script>
	{{-- <script> --}}
	{{--  	window.jQuery || document.write('<script src="js/vendor/jquery-3.2.1.min.js"><\/script>') --}}
	{{-- </script> --}}
	<script src="{{asset('/js/popper.js')}}">
	</script>
	{{-- <script src="{{asset('/js/toastr.min.js')}}"></script> --}}
	<script src="{{asset('/js/bootstrap-material-design.js')}}">
	</script>
	{{-- <script src="{{asset('/js/chart.js@2.8.0')}}"></script> --}}
	<script>
		$(document).ready(function () {
			$('body').bootstrapMaterialDesign();
		});
	</script>
	
	<script src="{{asset('/js/select2.min.js')}}"></script>
	<script src="{{asset('/js/main.js')}}"></script>
	{{-- Datatable --}}
	<script src="{{asset('/js/datatable/js/jquery.dataTables.min.js')}}"></script>
	<script src="{{asset('/js/datatable/js/dataTables.buttons.min.js')}}"></script>
	<script src="{{asset('/js/datatable/js/jszip.min.js')}}"></script>
	<script src="{{asset('/js/datatable/js/pdfmake.min.js')}}"></script>
	<script src="{{asset('/js/datatable/js/vfs_fonts.js')}}"></script>
	<script src="{{asset('/js/datatable/js/buttons.html5.min.js')}}"></script>
	<script src="{{asset('/js/datatable/js/buttons.print.min.js')}}"></script>
