<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>@yield('title') | Barber MIS</title>
	{{-- @yield('csrf') --}}
	<meta name="description" content="nozha admin panel fully support rtl with complete dark mode css to use. ">
	<meta name=”robots” content="index, follow">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="apple-touch-icon" sizes="180x180" href="{{asset('/img/favicon/apple-touch-icon.png')}}">
	<link rel="icon" type="image/png" sizes="32x32" href="{{asset('/img/favicon/favicon-32x32.png')}}">
	<link rel="icon" type="image/png" sizes="16x16" href="{{asset('/img/favicon/favicon-16x16.png')}}">
	<link rel="manifest" href="{{asset('/img/favicon/site.webmanifest')}}">
	<link rel="mask-icon" href="{{asset('/img/favicon/safari-pinned-tab.svg')}}" color="#5bbad5">
	<meta name="msapplication-TileColor" content="#2b5797">
	<meta name="theme-color" content="#ffffff">
	<!-- Place favicon.ico in the root directory -->
	<link rel="stylesheet" href="{{asset('/css/normalize.css')}}">
	<link href="{{asset('/css/fontawsome/all.min.css')}}" rel="stylesheet">
	<link rel="stylesheet"
		href="{{asset('/css/bootstrap-material-design.min.css')}}">

	<link rel="stylesheet" href="{{asset('/css/bootstrap.min.css')}}">
	<link href="{{asset('/css/toastr.min.css')}}" rel="stylesheet" />

	<link rel="stylesheet" href="{{asset('/css/animate.min.css')}}" />
	<link rel="stylesheet" href="{{asset('/css/select2.min.css')}}" />
	<link rel="stylesheet" href="{{asset('/js/datatable/css/buttons.dataTables.min.css')}}" />
	<link rel="stylesheet" href="{{asset('/js/datatable/css/jquery.dataTables.min.css')}}" />

	<link rel="stylesheet" href="{{asset('/css/main.css')}}">
	<link rel="stylesheet" href="{{asset('/css/style.css')}}">
</head>