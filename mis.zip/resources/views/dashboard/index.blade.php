@extends('app')
@section('title', 'Dashboard')

@section('content')
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row mb-2">
        <div class="col-xl-3 col-md-6 col-sm-6 p-2">
            <div class="box-dash animate__animated animate__flipInY b-first  "><i class="fab far fa-chart-bar" aria-hidden="true"></i>

                <span>{{isset($income->first()->income)? $income->first()->income : 0}}</span>
                <!-- <span>{{isset($bill_items)? $bill_items : 0}}</span> -->
                <hr class="m-0 ">
                <span>عواید </span>
                <a href="{{route('report.income')}}" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 col-sm-6 p-2">
            <div class="box-dash animate__animated animate__flipInY b-second   "><i class="fab far fa-clock" aria-hidden="true"></i>

                <span>{{$expense}}</span>
                <hr class="m-0 ">
                <span>مصارف </span>
                <a href="{{route('report.income')}}" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 col-sm-6 p-2">
            <div class="box-dash animate__animated animate__flipInY b-third  "><i class="fab far fa-comments" aria-hidden="true"></i>
                <span>{{$payment}}</span>
                <hr class="m-0 ">
                <span> پرداخت کارمند</span>
                <a href="" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 col-sm-6 p-2">
            <div class="box-dash animate__animated animate__flipInY b-forth  "><i class="fab far fa-gem" aria-hidden="true"></i>

                @php $balance = $income->first()->income - $expense - $payment- $products; @endphp
                <span>{{$balance}}</span>
                <hr class="m-0 ">
                <span>بلانس</span>
                <a href="{{route('bill.index')}}" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 col-sm-6 p-2">
            <div class="box-dash animate__animated animate__flipInY b-forth  "><i class="fab far fa-gem" aria-hidden="true"></i>
                <span>{{$products}}</span>
                <hr class="m-0 ">
                <span>محصولات</span>
                <a href="{{route('bill.index')}}" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <div class="col-xl-6 col-md-6 col-sm-6 p-2 bg-white">
         
                @if(isset($total_queue))

                <table class="table table-sm table-striped table-bordered">
                    <thead>
                        <tr>
                            <th scope="col"> #</th>
                            <th scope="col">اسم کارمند</th>
                            <th scope="col">تعداد</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php
                        // dd($logs)
                        $withdraw = 0;
                        $deposit = 0;
                        $tot = 0;
                        @endphp
                        @if(isset($total_queue))

                        @foreach ($total_queue as $k=>$v)
                        {{-- @dd($k) --}}
                        <tr>
                            <td>{{$k+1}}</td>
                            <td>{{$v->staff->name}}</td>
                            <td>{{$v->count}} </td>
                        </tr>
                        @php $tot +=$v->count; @endphp

                        @endforeach
                        @endif
                    </tbody>
                    <tfoot>
                        <tr>
                            <th></th>
                            <th>جمله</th>
                            <th>{{$tot}}</th>
                        </tr>
                    </tfoot>
                </table>
                @endif

        </div>

    </div>

    <div class="row m-1 my-5 d-none">
        <div class="col-xl-3 col-md-6 col-sm-6 p-2">
            <div class="box-card text-right mini animate__animated animate__flipInY   "><i class="fab far fa-chart-bar b-first" aria-hidden="true"></i>
                <span class="mb-1 c-first">عواید</span>
                <span>{{isset($allincome->first()->income)? $allincome->first()->income : 0}}</span>

                <p class="mt-3 mb-1 text-right"><i class="far fas fa-wallet mr-1 c-first"></i> در حال
                    پیشرفت</p>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 col-sm-6 p-2">
            <div class="box-card text-right mini animate__animated animate__flipInY    "><i class="fab far fa-clock b-second" aria-hidden="true"></i>
                <span class="mb-1 c-second">مصارف</span>
                <span>{{$allexpense}}</span>
                <p class="mt-3 mb-1 text-right"><i class="far fas fa-wifi mr-1 c-second"></i>در حال پیشرفت
                </p>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 col-sm-6 p-2">
            <div class="box-card text-right mini animate__animated animate__flipInY   "><i class="fab far fa-comments b-third" aria-hidden="true"></i>
                <span> پرداخت کارمند</span>
                <span>{{$allpayment}}</span>
                <p class="mt-3 mb-1 text-right"><i class="fab fa-whatsapp mr-1 c-third"></i>در حال پیشرفت
                </p>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 col-sm-6 p-2">
            <div class="box-card text-right mini animate__animated animate__flipInY   "><i class="fab far fa-gem b-forth" aria-hidden="true"></i>
                <span class="mb-1 c-third"> بلانس</span>
                @php $balance = $allincome->first()->income - $allexpense -$allpayment; @endphp
                <span>{{$balance}}</span>
                <p class="mt-3 mb-1 text-right"><i class="fab fa-bluetooth mr-1 c-forth"></i>در حال پیشرفت
                </p>
            </div>
        </div>
    </div>
    <!-- row closed-->

</div>
@endsection