@extends('app')
@section('title', 'Bill')

@section('content')
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>
                     
                     @if (isset($bill))
                     {{'ویرایش بل'}}
                     @else
                     {{'ثبت بل جدید'}}
                     @endif
                </h4>
                {{-- @if($errors->any())
                    {{ implode('', $errors->all('<div>:message</div>')) }}
                @endif --}}
            </div>
            @include('layouts.component.alert')
            <form class="" action="{{isset($bill) ? route('bill.update', $bill): route('bill.store')}}" method="POST">
                @csrf
                @if(isset($bill))
                    @method('PUT')
                @else
                    @method('POST')
                @endif
                
                <div class="form-row align-items-center">
                    <div class="col-6  col-sm-3">
                        <label class="" for="inlineFormInput">مشتری </label>
                        <input type="text" class="form-control " id="inlineFormInput" name="customer" value="{{isset($bill) ? $bill->customer: old('customer')}}">
                        @error('customer')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-6 col-sm-3">
                        <label class="" for="inlineFormInput">تاریخ </label>
                        <input type="date" class="form-control " id="inlineFormInput" name="bill_date" value="{{isset($bill) ? $bill->bill_date: old('bill_date')}}">
                        @error('bill_date')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                
                </div>
                <div class="form-row align-items-center mt-2">
                    <table class="table table-bordered jsGoodsTable table-sm">
                        <thead>
                            <tr>
                                <th>خدمات</th>
                                <th>کارمند</th>
                                <th>تعداد</th>
                                <th>نرخ</th>
                                <th>فیصدی</th>
                                <th>جمله</th>
                                <th>عمل</th>
                            </tr>
                        </thead>
                        <tbody>
                          
                            @foreach($bill->bill_detail as $detail)
                                <tr>
                                    <td class="ServiceId d-none">{{$detail->service->id}}</td>
                                    <td>
                                        {{$detail->service->name}}
                                    </td>
                                    <td class="StaffId d-none">{{$detail->staff_id}}</td>
                                    <td>
                                       
                                        {{$detail->staff->name}}
                                    </td>
                                    <td class="Qty">{{$detail->qty}}</td>
                                    <td class="Cost">{{$detail->cost}}</td>
                                    <td class="Cost">{{$detail->percentage_amount}}</td>
                                    <td class="Total">{{$detail->cost * $detail->qty}}</td>
                                    <td>
                                        <button type="button" style="width: 30px;" class="btn btn-sm f-forth text-center jsDeleteOld" onclick="Rowdelete(this)"> <i class="fa fa-times"></i><div class="ripple-container"></div></button>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>    
                
                <div class="form-row align-items-center">
                    <hr>
                </div>
                <div class="form-row align-items-center pt-2" style="border-top: 1px solid green;">
                    <div class="col-6  col-sm-3">
                        <label class="" for="inlineFormInputGroup">کارمند </label>
                        <select class="form-control " name="staff" id="staff">
                            <option value="">انتخاب نمایید</option>
                            @foreach ($staffs as $staff)
                            <option value="{{$staff->id}}" >{{$staff->name}} {{$staff->last_name}} </option>    
                            @endforeach
                        </select>    
                        @error('staff')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-6  col-sm-2">
                        <label class="" for="inlineFormInputGroup">خدمات </label>
                        <select class="form-control " name="service" id="service">
                            <option value="">انتخاب نمایید</option>
                            @foreach ($services as $service)
                            <option value="{{$service->id}}" data-cost="{{$service->cost}}">{{$service->name}} </option>    
                            @endforeach
                        </select>    
                        @error('service')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-4  col-sm-2">
                        <label class="" for="cost">تعداد </label>
                        <input type="text" class="form-control " id="qty" name="qty" value="1" >
                    </div>
                    <div class="col-4  col-sm-2">
                        <label class="" for="cost">نرخ </label>
                        <input type="text" class="form-control " readonly id="cost" name="cost" >
                    </div>
                    <div class="col-4  col-sm-2">
                        <label class="" for="cost">جمله </label>
                        <input type="text" class="form-control " readonly id="total" name="total" >
                    </div>
                    
                    <div class="col-3  col-sm-1">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="button" class="btn btn-block f-first text-center jsAddGood"> <i class="fa fa-plus"></i></button>
                    </div>
                    
                </div>

                <div class="form-row align-items-center">
                    <hr>
                </div>

                <div class="form-row align-items-center mt-2">
                    <table class="table table-bordered jsProductsTable table-sm">
                        <thead>
                            <tr>
                                <th>محصولات</th>
                                <th>تعداد</th>
                                <th>نرخ</th>
                                <th>جمله</th>
                                <th>عمل</th>
                            </tr>
                        </thead>
                        <tbody>
                          
                            @foreach($bill->bill_product as $product)
                                <tr>
                                    <td class="product_id d-none">{{$product->product->id}}</td>
                                    <td class="purchase d-none">{{$product->purchase}}</td>
                                    <td>
                                        {{$product->product->name}}
                                    </td>
                                  
                                    <td class="p_qty">{{$product->qty}}</td>
                                    <td class="p_cost">{{$product->sell}}</td>
                                    <td class="Total">{{$product->sell * $product->qty}}</td>
                                    <td>
                                        <button type="button" style="width: 30px;" class="btn btn-sm f-forth text-center jsDeleteOld" onclick="RowPdelete(this)"> <i class="fa fa-times"></i><div class="ripple-container"></div></button>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>   
                <div class="form-row align-items-center pt-2" style="border-top: 1px solid rgb(228, 7, 7);">
                    <div class="col-6  col-sm-3">
                        <label class="" for="inlineFormInputGroup">محصولات </label>
                        <select class="form-control " name="product" id="product">
                            <option value="">انتخاب نمایید</option>
                            @foreach ($products as $product)
                                <option value="{{$product->id}}" data-available="{{$product->qty}}"  data-sell="{{$product->sell}}" data-purchase="{{$product->purchase}}">{{$product->name}}</option>    
                            @endforeach
                        </select>    
                        @error('product')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-4  col-sm-2">
                        <label class="" for="cost">موجود </label>
                        <input type="text" class="form-control " readonly id="available" name="available" >
                    </div>
                    
                    <div class="col-4  col-sm-2">
                        <label class="" for="cost">تعداد </label>
                        <input type="text" class="form-control " id="p_qty" name="p_qty" value="1" >
                    </div>
                    <div class="col-4  col-sm-2">
                        <label class="" for="cost">نرخ </label>
                        <input type="text" class="form-control " readonly id="p_cost" name="p_cost" >
                        <input type="hidden" class="form-control " readonly id="purchase" name="purchase" >
                    </div>
                    <div class="col-4  col-sm-2">
                        <label class="" for="cost">جمله </label>
                        <input type="text" class="form-control " readonly id="p_total" name="p_total" >
                    </div>

                    <div class="col-3  col-sm-1">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="button" class="btn btn-block f-third text-center jsAddProduct"> <i class="fa fa-plus"></i></button>
                    </div>

                </div>
                

                <div class="form-row align-items-center mt-2">
                    <input type="hidden" class="" name="hfGoodList" value="" id="hfGoodList" placeholder="json enc" />
                    <input type="hidden" class="" name="hfProductList" value="" id="hfProductList" placeholder="json enc" />
                    
                    <div class="col-4  col-sm-2">
                        <label class="" for="cost">مجموع </label>
                        <input type="number" class="form-control " readonly id="grand_total" name="grand_total" value="{{$bill->total}}">
                        @error('grand_total')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-4  col-sm-2">
                        <label class="" for="cost">تخفیف </label>
                        <input type="number" class="form-control " id="discount" name="discount"  value="{{$bill->discount}}">
                    </div>
                    <div class="col-4  col-sm-2">
                        <label class="" for="cost">قابل پرداخت </label>
                        <input type="number" class="form-control " readonly id="payable" name="payable" value="{{$bill->total-$bill->discount}}">
                    </div>
                    <div class="col-4 col-sm-1">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block {{isset($service) ?'f-primary':'f-secondary' }} text-center"  onclick="return getData()">  {{isset($service) ?'ویرایش':'ثبت' }}</button>
                    </div>
                </div>
            </form>
        </div>

    </div>
</div>
@endsection

@section('pagescript')
    <script src="{{asset('/js/bill/edit.js')}}"></script>
@endsection
