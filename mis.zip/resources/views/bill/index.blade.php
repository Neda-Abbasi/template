@extends('app')
@section('title', 'Bills')

@section('content')
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">

            @include('layouts.component.alert')
            
            <h4 class="card-title">لست بل ها</h4>

            <hr>
            <table class="table table-sm table-striped table-bordered" id="datatable">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">بل</th>
                        <th scope="col">مشتری</th>
                        <th scope="col">جمله</th>
                        <th scope="col">تخفیف</th>
                        <th scope="col">تاریخ</th>
                        <th scope="col">عمل</th>
                    </tr>
                </thead>
                <tbody>
                    @php $c = 1 @endphp
                    @foreach ($bills as $bill)
                        
                    <tr>
                        <td scope="row">{{$c++}} </td>
                        <td>{{$bill->id}}</a></td>
                        <td>{{$bill->customer}} </td>
                        <td>{{$bill->total}} </td>
                        <td>{{$bill->discount}}</td>
                        <td>{{$bill->bill_date}}</td>
                        <td>
                            <a href="{{route('bill.edit', $bill)}}" title="ویرایش" class="btn btn-success btn-sm d-inline"><i class="fa fa-edit"></i></a>  
                            <a href="{{route('bill.show', $bill)}}" title="رسید" class="btn f-third btn-sm d-inline"> <i class="fa fa-file-pdf"></i></a>

                            {{-- <form action="{{route('bill.destroy', $bill)}}" method="post" class="d-inline">
                                @method('delete')
                                @csrf
                                <button type="submit" class="btn btn-sm f-danger "> <i class="fa fa-times"></i> </button>
                              </form> --}}

                        </td>
                    </tr>
                    @endforeach
                    
                </tbody>
            </table>
            

        </div>



    </div>
</div>
@endsection

