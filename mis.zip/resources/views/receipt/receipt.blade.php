<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Receipt</title>
	<!-- Tell the browser to be responsive to screen width -->
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<!-- Bootstrap 3.3.6 -->
	<link rel="stylesheet" href="{{asset('/css/bootstrap.min.css')}}">
	<!-- Font Awesome -->
	{{-- <link rel="stylesheet" href="<?php //echo SITE_URL; ?>/dist/css/font-awesome.min.css"> --}}
	{{-- <link rel="stylesheet" href="<?php //echo SITE_URL; ?>/dist/css/AdminLTE.min.css"> --}}
	<link rel="stylesheet" href="{{asset('/css/print.css')}}">
</head>
<script type="text/javascript">

        window.onafterprint = back;

        // function back() {
        //     // window.history.back(); It goes one step back which again prompts for form submission
		// 	window.history.go(-2);
        // }
    </script>
<body onload="window.print();">
	<!--
<body>-->
	<div class="wrapper">
		<!-- Main content -->
		<section class="invoice">

			<!-- /.row -->
			<div class="print-box jsBillPrintBox cook-bill">
				<table class="print-tbl restaurant-specs">
					<tbody>
						<tr>
							<td class="sbold text-center"><img src="{{asset('img/logo.jpeg')}}" width="80%"></td>
						</tr>
					</tbody>
				</table>
			
				<table class="print-tbl bill-info jsBillInfo text-right">
					<tbody>
						<tr>
							<td colspan="2"> <strong>برداشت پول از حساب</strong>  </td>
						</tr>
						<tr>
							<td>{{ date('d-m-Y', strtotime($log->created_at)) }}</td>
							<td>تاریخ </td>
						</tr>
						<tr>
							<td>{{ $log->id }}</td>
							<td>بل نمبر </td>
						</tr>
						<tr>
							<td>{{ $log->client->name }} ({{ $log->id }})</td>
							<td>مشتری </td>
						</tr>
						<tr>
							<td >{{ $log->amount }}</td>
							<td >مبلغ</td>
						</tr>
						<tr>
							<td >{{ $log->currency }}</td>
							<td >اسعار</td>
						</tr>
						
					</tbody>
				</table>
				

				<table class="print-tbl cook-show">
					<tbody>
						<tr>
							<td class="dotted full" colspan="4">
								<hr />
							</td>
						</tr>
					</tbody>
				</table>
				<table class="print-tbl restaurant-specs ">
					<tbody>
						<tr>
							<td class="text-center">سرای شهزاده</td>
						</tr>

						<tr>
							<td class="text-center">دوکان نمبر ۱، منزل دوم</td>
						</tr>
					</tbody>
				</table>
				
			</div>

			<!-- /.row -->
		</section>
		<!-- /.content -->
	</div>
	<!-- ./wrapper -->
</body>

</html>
