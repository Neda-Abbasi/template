<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Receipt</title>
	<!-- Tell the browser to be responsive to screen width -->
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<!-- Bootstrap 3.3.6 -->
	<link rel="stylesheet" href="{{asset('/css/bootstrap.min.css')}}">
	<!-- Font Awesome -->
	{{-- <link rel="stylesheet" href="<?php //echo SITE_URL; ?>/dist/css/font-awesome.min.css"> --}}
	{{-- <link rel="stylesheet" href="<?php //echo SITE_URL; ?>/dist/css/AdminLTE.min.css"> --}}
	<link rel="stylesheet" href="{{asset('/css/print.css')}}">
</head>
<script type="text/javascript">

        window.onafterprint = back;

        function back() {
            // window.history.back(); It goes one step back which again prompts for form submission
			window.history.go(-2);
        }
    </script>
<body onload="window.print();">
	<!--
<body>-->
	<div class="wrapper">
		<!-- Main content -->
		<section class="invoice">
			

			<!-- /.row -->
			<div class="print-box jsBillPrintBox cook-bill">
				<table class="print-tbl restaurant-specs" border="1">
					<tbody>
						<tr>
							<td class="sbold text-center"><img src="{{asset('img/logo.jpg')}}" width="80%"></td>
						</tr>
						
					</tbody>
				</table>
			
				<table class="print-tbl bill-info jsBillInfo" dir="rtl">
					<tbody>
						<tr>
							<td> تاریخ : <span class="jsBillDate">{{ $bill->created_at }}</span></td>
							<td>بل : <span class="jsBillNo">{{ $bill->id }}</span> </td>
						</tr>
						<tr>
							<td colspan="2">مشتری : <span class="jsOrderType">{{ $bill->customer }}</span> </td>
						</tr>
					</tbody>
				</table>
				<table class="print-tbl">
					<tbody class="jsBillItems" dir="rtl">
						<tr>
							<td class="dotted full" colspan="5">
								<hr />
							</td>
						</tr>
						<tr>
							<td class="mrl5">خدمات</td>
							<td class="mrl5 ">تعداد</td>
							<td class="mrl5">نرخ</td>
							<td class="mrl5">جمله</td>
						</tr>

						<tr>
							<td class="dotted full" colspan="5">
								<hr />
							</td>
						@foreach($bill->bill_detail as $obj)
							</tr>
							<td class="mrl5">{{ $obj->service->name }}</td>
								<td class="mrl5">{{ $obj->qty }}</td>
								<td class="mrl5">{{ $obj->cost }}</td>
								<td class="mrl5">{{ $obj->qty * $obj->cost }}</td>
							</tr>
						@endforeach
						<tr>
							<td class="dotted full" colspan="4">
								<hr />
							</td>
						</tr>
					</tbody>
				</table>
				<table class="print-tbl" dir="rtl">
					<tbody>
						<tr>
							<td class="text-right" colspan="5">جمله: </td>
							<td class="text-right jsSubTotal">{{ $bill->total }}</td>
						</tr>
						 @if ($bill->discount > 0) 
						<tr>
							<td class="text-right" colspan="5">تخفیف: </td>
							<td class="text-right jsSubTotal">{{$bill->discount}}</td>
						</tr>
						@endif
						<tr>
							<td class="text-right" colspan="5">مجموع: </td>
							<td class="text-right jsSubTotal">{{ $bill->total-$bill->discount }}</td>
						</tr>
					</tbody>
				</table>
				
				<table class="print-tbl cook-show">
					<tbody>
						<tr>
							<td class="dotted full" colspan="4">
								<hr />
							</td>
						</tr>
					</tbody>
				</table>
				<table class="print-tbl restaurant-specs ">
					<tbody>
						<tr>
							<td class="text-center">پل محمودخان گلبهار تاورز کابل افغانستان</td>
						</tr>
						
					</tbody>
				</table>
				<table class="print-tbl" dir="rtl">
					<tbody>
						<tr>
							<td class="text-center">شماره تماس: 0780621421</td>
						</tr>
						<tr>
							<td dir="ltr" class="text-center"><img src="{{asset('/img/fb.png')}}" />: New York hair salon</td>
						</tr>
					</tbody>
				</table>
			</div>

			<!-- /.row -->
		</section>
		<!-- /.content -->
	</div>
	<!-- ./wrapper -->
</body>

</html>
