<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Receipt</title>
	<!-- Tell the browser to be responsive to screen width -->
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<!-- Bootstrap 3.3.6 -->
	<link rel="stylesheet" href="{{asset('/css/bootstrap.min.css')}}">
	<!-- Font Awesome -->
	{{-- <link rel="stylesheet" href="<?php //echo SITE_URL; ?>/dist/css/font-awesome.min.css"> --}}
	{{-- <link rel="stylesheet" href="<?php //echo SITE_URL; ?>/dist/css/AdminLTE.min.css"> --}}
	<link rel="stylesheet" href="{{asset('/css/print.css')}}">
</head>
<script type="text/javascript">

        window.onafterprint = back;

        // function back() {
        //     // window.history.back(); It goes one step back which again prompts for form submission
		// 	window.history.go(-2);
        // }
    </script>
<body onload="window.print();">
	<!--
<body>-->
	<div class="wrapper">
		<!-- Main content -->
		<section class="invoice">
			

			<!-- /.row -->
			<div class="print-box jsBillPrintBox cook-bill">
				<table class="print-tbl restaurant-specs">
					<tbody>
						<tr>
							<td class="sbold text-center"><img src="{{asset('img/logo.jpg')}}" width="80%"></td>
						</tr>
						<tr>
							<td class="sbold text-center">New York Hair Salon</td>
						</tr>
					</tbody>
				</table>
			
				<table class="print-tbl bill-info jsBillInfo">
					<tbody>
						<tr>
							<td>Date: <span class="jsBillDate">{{ $bill->bill_date }}</span></td>
							<td>Bill No: <span class="jsBillNo">{{ $bill->id }}</span></td>
						</tr>
						<tr>
							<td>Client: <span class="jsOrderType">{{ $bill->customer }}</span></td>
							<!--<td>W. No.: <span class="jsOrderTaker">22</span></td>-->
						</tr>
					</tbody>
				</table>
				<table class="print-tbl">
					<tbody class="jsBillItems">
						<tr>
							<td class="dotted full" colspan="5">
								<hr />
							</td>
						</tr>
						<tr>
							<td class="mrl5">Item</td>
							<td class="mrl5 ">Qty</td>
							<td class="mrl5">Rate</td>
							<td class="mrl5">Total</td>
						</tr>

						<tr>
							<td class="dotted full" colspan="5">
								<hr />
							</td>
						@foreach($bill->bill_detail as $obj)
							</tr>
							<td class="mrl5">{{ $obj->service->name }}</td>
								<td class="mrl5">{{ $obj->qty }}</td>
								<td class="mrl5">{{ $obj->cost }}</td>
								<td class="mrl5">{{ $obj->qty * $obj->cost }}</td>
							</tr>
						@endforeach
						<tr>
							<td class="dotted full" colspan="5">
								<hr />
							</td>
						</tr>
						
					</tbody>
				</table>
				<table class="print-tbl">
					<tbody>
						
						<tr>
							<td class="text-right" colspan="5">Sub Total: </td>
							<td class="text-center jsSubTotal">{{ $bill->total }}</td>
						</tr>
						 @if ($bill->discount > 0) 
						<tr>
							<td class="text-right" colspan="5">Discount: </td>
							<td class="text-center jsSubTotal">{{$bill->discount}}</td>
						</tr>
						@endif
						<tr>
							<td class="text-right" colspan="5">Total: </td>
							<td class="text-center jsSubTotal">{{ $bill->total-$bill->discount }}</td>
						</tr>
					</tbody>
				</table>
				
				<table class="print-tbl cook-show">
					<tbody>
						<tr>
							<td class="dotted full" colspan="4">
								<hr />
							</td>
						</tr>
					</tbody>
				</table>
				<table class="print-tbl restaurant-specs ">
					<tbody>
						<tr>
							<td class="text-center">Pul-e-Mahmood khan</td>
						</tr>

						<tr>
							<td class="text-center">Gulbahar Towers, Kabul Afghanistan</td>
						</tr>
					</tbody>
				</table>
				<table class="print-tbl">
					<tbody>
						<tr>
							<td class="text-center">Phone: +93 0780621421</td>
						</tr>
						<tr>
							<td class="text-center">FB Page: New York hair salon</td>
						</tr>
					</tbody>
				</table>
			</div>

			<!-- /.row -->
		</section>
		<!-- /.content -->
	</div>
	<!-- ./wrapper -->
</body>

</html>
