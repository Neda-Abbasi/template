@extends('app')
@section('title', 'service')

@section('content')
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>
                     @if (isset($service))
                     {{'ویرایش خدمات کارمند'}}
                     @else
                     {{'ثبت خدمات کارمند'}}
                     @endif
                </h4>
                {{-- @if($errors->any())
                    {{ implode('', $errors->all('<div>:message</div>')) }}
                @endif --}}
            </div>
            @include('layouts.component.alert')
            <form class="" action="{{route('staff.service.post', $service)}}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('POST')
                
                <div class="form-row align-items-center">
                    <div class="col-3">
                        <label class="" for="inlineFormInput">نام </label>
                        <input type="text" class="form-control " readonly id="inlineFormInput" name="name" value="{{isset($service) ? $service->staff->name: old('name')}}">
                        @error('name')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    
                    <div class="col-3">
                        <label class="" for="fathername"> خدمات</label>
                        <input type="text" class="form-control " readonly id="fathername" name="fathername" value="{{isset($service) ? $service->service->name: old('fathername')}}">
                        @error('fathername')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                  
                    <div class="col-3">
                        <label class="" for="inlineFormInputGroup"> فیصدی</label>
                        <input type="number" step="0.1" class="form-control " id="percentage" name="percentage"  value="{{isset($service) ? $service->percentage: old('percentage')}}">
                        @error('percentage')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-3">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block {{isset($service) ?'f-primary':'f-secondary' }} text-center"> {{isset($service) ?'ویرایش':'ثبت' }}</button>
                    </div>
                </div>
            </form>
        </div>

    </div>
</div>
@endsection
