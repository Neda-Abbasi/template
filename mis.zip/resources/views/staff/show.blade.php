@extends('app')
@section('title', 'Staff')

@section('content')
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">

            @include('layouts.component.alert')
            <div class="col-sm-12 d-flex  justify-content-between">
                <h4 class="card-title">لست خدمات کارمند</h4>
                <a href="{{route('percentage.create')}}" class="btn btn-sm f-secondary ">تعین خدمات</a>
            </div>
            <hr>
            <table class="table table-sm table-striped table-bordered" id="">
                <thead>
                    <tr>
                        <th scope="col">نام</th>
                        <th scope="col">خدمات</th>
                        <th scope="col">فیصدی</th>
                        <th scope="col">عمل</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($staffs as $staff)
                        
                    <tr>
                        <td>{{$staff->staff->name}}</td>
                        <td>{{$staff->service->name}} </td>
                        <td>{{$staff->percentage}}</td>
                        <td><a href="{{route('staff.service.get', $staff)}}" title="ویرایش" class="btn btn-success btn-sm"><i class="fa fa-edit"></i></a>  
                       
                        </td>
                    </tr>
                    @endforeach
                    
                </tbody>
            </table>
            
        </div>

    </div>
</div>
@endsection

@section('pagescript')
    <script src="/js/client/index.js"></script>
@endsection

