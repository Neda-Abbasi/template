@extends('app')
@section('title', 'service')

@section('content')
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>
                     {{'ثبت خدمات کارمند'}}
                </h4>
                {{-- @if($errors->any())
                    {{ implode('', $errors->all('<div>:message</div>')) }}
                @endif --}}
            </div>
            @include('layouts.component.alert')
            <form class="" action="{{route('percentage.store')}}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('POST')
                
                <div class="form-row align-items-center">
                    <div class="col-6  col-sm-3">
                        <label class="" for="inlineFormInputGroup">کارمند </label>
                        <select class="form-control " name="staff" id="staff">
                            <option value="">انتخاب نمایید</option>
                            @foreach ($staff as $staf)
                                <option value="{{$staf->id}}" >{{$staf->name}} {{$staf->last_name}} </option>    
                            @endforeach
                        </select>    
                        @error('staff')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-6  col-sm-3">
                        <label class="" for="inlineFormInputGroup">خدمات </label>
                        <select class="form-control " name="service" id="service">
                            <option value="">انتخاب نمایید</option>
                            @foreach ($services as $service)
                                <option value="{{$service->id}}" data-cost="{{$service->cost}}">{{$service->name}} </option>    
                            @endforeach
                        </select>    
                        @error('service')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                  
                    <div class="col-3">
                        <label class="" for="inlineFormInputGroup"> فیصدی</label>
                        <input type="number" step="0.1" class="form-control " id="percentage" name="percentage"  value="{{old('percentage')}}">
                        @error('percentage')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-3">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block f-primary text-center">ثبت</button>
                    </div>
                </div>
            </form>

            <table class="table table-sm table-striped table-bordered" id="">
                <thead>
                    <tr>
                        <th scope="col">نام</th>
                        <th scope="col">خدمات</th>
                        <th scope="col">فیصدی</th>
                        <th scope="col">عمل</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($staffs as $staff)
                        
                    <tr>
                        <td>{{$staff->staff->name}}</td>
                        <td>{{$staff->service->name}} </td>
                        <td>{{$staff->percentage}}</td>
                        <td class="d-flex"><a href="{{route('staff.service.get', $staff)}}" title="ویرایش" class="btn btn-success btn-sm" style="height: 35px;"><i class="fa fa-edit"></i></a>  
                            {{-- <form action="{{route('percentage.destroy', $staff)}}" method="post" class="d-inline">
                                @method('delete')
                                @csrf
                                <button type="submit" class="btn btn-sm f-danger "> <i class="fa fa-times"></i> </button>
                            </form> --}}
                        </td>
                    </tr>
                    @endforeach
                    
                </tbody>
            </table>
        </div>

    </div>
</div>
@endsection
