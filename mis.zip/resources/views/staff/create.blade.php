@extends('app')
@section('title', 'Staff')

@section('content')
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>
                     
                     @if (isset($staff))
                     {{'ویرایش کارمند'}}

                     @else
                     {{'ثبت و راجستر کارمند'}}

                     @endif
                </h4>
                {{-- @if($errors->any())
                    {{ implode('', $errors->all('<div>:message</div>')) }}
                @endif --}}
            </div>
            @include('layouts.component.alert')
            <form class="" action="{{isset($staff) ? route('staff.update', $staff): route('staff.store')}}" method="POST" enctype="multipart/form-data">
                @csrf
                @if(isset($staff))
                    @method('PUT')
                @else
                    @method('POST')
                @endif
                
                <div class="form-row align-items-center">
                    <div class="col-3">
                        <label class="" for="inlineFormInput">نام </label>
                        <input type="text" class="form-control " id="inlineFormInput" name="name" value="{{isset($staff) ? $staff->name: old('name')}}">
                        @error('name')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-3">
                        <label class="" for="inlineFormInput">تخلص </label>
                        <input type="text" class="form-control " id="inlineFormInput" name="last_name" value="{{isset($staff) ? $staff->last_name: old('last_name')}}">
                        @error('last_name')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-3">
                        <label class="" for="fathername">نام پدر</label>
                        <input type="text" class="form-control " id="fathername" name="fathername" value="{{isset($staff) ? $staff->fathername: old('fathername')}}">
                        @error('fathername')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-3">
                        <label class="" for="inlineFormInputGroup">شماره تماس</label>
                        <input type="tel" class="form-control " name="mobile"  value="{{isset($staff) ? $staff->mobile: old('mobile')}}">
                        @error('mobile')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    
                    <div class="col-2">
                        <label class="" for="inlineFormInputGroup">نوع کارمند</label>
                        <select class="form-control " name="type" id="type">
                            <option value="fixed" @if(isset($staff)) @if($staff->type== 'fixed'){{ 'selected' }} @endif @endif>معاش ثابت</option>
                            <option value="percentage" @if(isset($staff)) @if($staff->type== 'percentage'){{ 'selected' }} @endif @endif>فیصدی</option>
                            <option value="servant" @if(isset($staff)) @if($staff->type== 'servant'){{ 'selected' }} @endif @endif>خدمه</option>
                        </select>    
                        @error('type')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-2">
                        <label class="" for="inlineFormInputGroup"> معاش</label>
                        <input type="number" step="0.1" class="form-control " id="salary" name="salary"  value="{{isset($staff) ? $staff->salary: old('salary')}}">
                        @error('salary')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-6">
                        <label class="" for="inlineFormInputGroup">آدرس</label>
                        <input type="text" class="form-control " name="address"  value="{{isset($staff) ? $staff->address: old('address')}}">
                        @error('address')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    
                    
                    <div class="col-2">
                        <label class="" for="inlineFormInputGroup">سند</label>
                        <input type="file" class="form-control " name="photo" >
                        @error('photo')
                        <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    @if(isset($staff))
                        <div class="col-12 col-sm-4 col-md-3 mt-3">
                            <label class="" for="inlineFormInputGroup"> </label>

                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" @if($staff->status == 1){{'checked'}} @endif name="status" id="deposit" value="1">
                                <label class="form-check-label" for="deposit">
                                فعال
                                </label>
                            </div>
                            <div class="form-check  form-check-inline">
                                <input class="form-check-input" type="radio" @if($staff->status == 0){{'checked'}} @endif name="status" id="withdraw" value="0">
                                <label class="form-check-label" for="withdraw">
                                غیرفعال
                                </label>
                            </div>
                        </div>
                    @endif
                </div>
                <div class="form-row align-items-center mt-2 services">
                    @if(!isset($staff) )
                    <h4 >خدمات</h4>
                        <div class="col-12 col-offset-2 mt-2">
                            <table class="table table-sm table-striped table-bordered ">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">خدمات</th>
                                        <th scope="col">فیصدی</th>
                                    
                                    </tr>
                                </thead>
                                <tbody>
                                    @php $c = 1; 
                                    @endphp
                                    @foreach ($services as $obj)
                                    <tr>
                                        <td scope="row">{{$c++}} </td>
                                        <td>{{$obj->name}}<input type="hidden" name="service[]" value="{{$obj->id}}" /></td>
                                        <td><input type="text" name="percentage[]" class=" form-control" style="padding: 0; margin:0; height:35px;" /></td>
                                    </tr>
                                    @endforeach
                                    
                                </tbody>
                            </table>
                        </div>    
                    @endif   
                </div>
                <div class="form-row align-items-center mt-2">
                    <div class="col-1">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block {{isset($staff) ?'f-primary':'f-secondary' }} text-center"> {{isset($staff) ?'ویرایش':'ثبت' }}</button>
                    </div>
                </div>
            </form>
        </div>

    </div>
</div>
@endsection
@section('pagescript')
    <script src="{{asset('/js/staff/create.js')}}"></script>
@endsection
