<!DOCTYPE html>
<html lang="en" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

  <title>PDF</title>
  <link href="https://fonts.googleapis.com/css2?family=Amiri&display=swap" rel="stylesheet">
    <style type="text/css">
        body{
            direction: rtl;
            font-family: XB Zar, Lateef, XBRiyaz, DejaVu Sans, monospace;
        }
        .title{
            font-size:32px !important;
        }
        .subtitle{
            font-size:26px !important;
        }
    .uper {
      margin-top: 40px;
    }
    .text-center{
        text-align: center;
    }
    .text-right{
        text-align: right;
    }
    </style>
</head>
<body>
<div >
  <div class="container">
    <table border="1" width="100%">
        <tr>
            <th colspan="2"><h1 class="title text-center">خدمات پولی نت هب</h1></th>
        </tr>
        <tr>
            <th  colspan="2"><h3  class="subtitle text-center">آدرس: گلبهار سنتر منزل اول، دوکان شماره ۲۰</h3></th>
        </tr>
        <tr>
            <th  colspan="2"> <h3 class="text-center">شماره تماس: ۰۷۸۰۱۰۰۶۷۶</p></th>
        </tr>
        <tr>
            <th class="text-right">تاریخ</th>
            <td class="text-right">{!! date('d-m-Y', strtotime($created_at)) !!}</td>
        </tr>
        <tr>
            <th class="text-right">نمبر حواله </th>
            <td class="text-right" >{{$hawala}}</td>
        </tr>
        <tr>
            <th class="text-right">نام فرستنده </th>
            <td class="text-right">{{$name}}</td>
        </tr>
        <tr>
            <th class="text-right">نام گیرنده </th>
            <td class="text-right">{{$receiver_name}}</td>
        </tr>
        <tr>
            <th class="text-right">مبلغ</th>
            <td class="text-right" >{{$amount}}</td>
        </tr>
        <tr>
            <th class="text-right">از کجا </th>
            <td class="text-right">{{$source}}</td>
        </tr>
        <tr>
            <th class="text-right">به کجا </th>
            <td class="text-right">{{$destination}}</td>
        </tr>
    </table>

    <table width="100%">
        <tr>
            <th width="50%">امضا گیرنده</th>
            <th width="50%">مهر و تاپه</th>
        </tr>
    </table>
  
</div>
</div>
</body>
</html>