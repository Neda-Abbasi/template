@extends('app')
@section('title', 'Staff')

@section('content')
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>
                     
                     @if (!isset($queueNumber))
                     {{'افزودن نوبت  '}}

                     @else
                     {{'ویرایش نوبت  '}}
                     @endif
                </h4>
                {{-- @if($errors->any())
                    {{ implode('', $errors->all('<div>:message</div>')) }}
                @endif --}}
                @php 
                // dd($queue); 
                @endphp
            </div>
            @include('layouts.component.alert')
            <form class="" action="{{isset($queueNumber) ? route('queue_number.update', $queueNumber): route('queue_number.store')}}" method="POST" >
                @csrf
                @if(isset($queueNumber))
                    @method('PUT')
                @else
                    @method('POST')
                @endif
                
                <div class="form-row align-items-center">
                <div class="col-4">
                        <label class="" for="customer">مشتری</label>
                        <input type="text" class="form-control "  id="customer" name="customer" value="{{isset($queueNumber) ? $queueNumber->customer:''}}">
                    </div>
                   
                    <div class="col-6  col-sm-4">
                        <label class="" for="inlineFormInputGroup">کارمند </label>
                        <select class="form-control " name="staff1" id="staff1">
                            <option value="">انتخاب نمایید</option>
                            @foreach ($staffs as $staff)
                                <option value="{{$staff->id}}"   @if(isset($queueNumber)) @if($staff->id == $queueNumber->staff_id){{'selected'}} @endif @endif>{{$staff->name}} {{$staff->last_name}} </option>    
                            @endforeach
                        </select>    
                        @error('staff')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                  
                  

                    <div class="col-1">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block {{isset($queueNumber) ?'f-primary':'f-secondary' }} text-center"> {{isset($queueNumber) ?'ویرایش':'ثبت' }}</button>
                    </div>
                </div>
            </form>
        </div>

    </div>
</div>
@endsection

@section('pagescript')

@endsection

