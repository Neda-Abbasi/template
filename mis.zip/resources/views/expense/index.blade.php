@extends('app')
@section('title', 'Expense')

@section('content')
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>
                     ثبت مصارف
                </h4>
                {{-- @php dd($expense); @endphp --}}
                @if ($errors->any())
                <div class="text-center">
                    @foreach ($errors->all() as $error)
                        <span class="text-danger"> {{ $error }} </span><br>
                    @endforeach
                </div>
                @endif
            </div>
            @include('layouts.component.alert')
            <form action="{{ isset($expense) ? route('expense.update', $expense) : route('expense.store') }}" method="post" enctype="multipart/form-data">
                @csrf
                @if(isset($expense))
                    @method('PUT')
                @else
                    @method('POST')
                @endif
                
                <div class="form-row align-items-center">
                    <div class="col-3">
                        <label class="" for="inlineFormInputGroup">تاریخ </label>
                        <input type="date" class="form-control " name="expense_date"  value="{{isset($expense) ? $expense->expense_date: old('expense_date')}}">
                        @error('expense_date')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-3">
                        <label class="" for="inlineFormInputGroup">کتگوری </label>
                        <select class="form-control " name="category" id="category">
                            @foreach($categories as $category)
                                <option value="{{$category->id}}" @if (isset($expense)) @if($expense->expense_category_id == $category->id) selected="selected" @endif @endif>{{$category->name}}</option>    
                            @endforeach
                        </select>    
                        @error('doc_type')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-6">
                        <label class="" for="inlineFormInput">تفصیلات</label>
                        <input type="text" class="form-control " id="inlineFormInput" name="description" value="{{isset($expense) ? $expense->description: old('description')}}">
                        @error('description')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-3">
                        <label class="" for="fathername"> مبلغ</label>
                        <input type="number" class="form-control " id="amount" name="amount" value="{{isset($expense) ? $expense->amount: old('amount')}}">
                        @error('amount')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    
                   
                    <div class="col-5">
                        <label class="" for="inlineFormInputGroup"> بل</label>
                        <input type="file" class="form-control " name="photo" >
                        @error('photo')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    
                    <div class="col-1">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block {{isset($expense) ?'f-primary':'f-secondary' }} text-center"> {{isset($expense) ?'ویرایش':'ثبت' }}</button>
                    </div>
                </div>

            </form>
    
            <h5 class="card-title">لست مصارفات</h5>

            <hr>
            <table class="table table-sm table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">کتگوری</th>
                        <th scope="col">تفصیلات</th>
                        <th scope="col">مبلغ</th>
                        <th scope="col">تاریخ</th>
                        <th scope="col">عمل</th>
                    </tr>
                </thead>
                <tbody>
                    @php $c = 1 @endphp
                    @foreach ($expenses as $expense)
                        
                    <tr>
                        <td scope="row">{{$c++}} </td>
                        <td>{{$expense->expense_category->name}}</td>
                        <td>{{$expense->description}} </td>
                        <td>{{$expense->amount}} </td>
                        <td>{{ date('d-m-Y', strtotime($expense->expense_date)) }}</td>

                        <td><a href="{{route('expense.edit', $expense)}}" title="ویرایش" class="btn btn-success btn-sm"><i class="fa fa-edit"></i></a>  
                        
                        </td>
                    </tr>
                    @endforeach
                    
                </tbody>
            </table>
            

        </div>



    </div>
</div>
@endsection
