<!doctype html>
<html class="no-js" lang="">
@include('layouts.header')
@section('title', 'Sarafi MIS Login')
<body class="gradient rtl" style="overflow: hidden">

	<div class="bmd-layout-container bmd-drawer-f-l avam-container animated ">
		<main class="bmd-layout-content">
			<div class="container-fluid">
				<div class="main_wrapper">

					
                    <!-- form -->

                    <div class="row ">
                        <div class="col-md-5 card shade mw-center mh-center">
                            @include('layouts.component.alert')
                            <img src="{{asset('img/logo.jpeg')}}" alt="..." class="mw-center " height="" width="200" >
                            <hr class="hr-dashed m-0">
                            <form class="" action="{{route('login')}}" method="POST">
                                @csrf
                                <div class="form-group m-0">
                                    <label for="exampleInputEmail1">نام کاربر</label>
                                    <input type="text" class="form-control" id="exampleInputEmail1"
                                        aria-describedby="emailHelp" name="name">
                                    @error('name')
                                        <span class="alert text-danger ">{{$message}}</span>
                                    @enderror
                                </div>
                                <div class="form-group m-0">
                                    <label for="exampleInputPassword1">رمز کاربر</label>
                                    <input type="password" class="form-control" id="exampleInputPassword1" name="password">
                                    @error('password')
                                        <span class="alert text-danger ">{{$message}}</span>
                                    @enderror
                                </div>
                                <div class="form-check pt-2">
                                    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="remember">
                                    <label class="form-check-label" for="exampleCheck1">بخاطر بسپار</label>
                                </div>
                                <button type="submit" class="btn shade f-primary btn-block text-center">ارسال</button>
                            </form>
                            <div class="col-12 text-center pb-2">

                                <a href="https://nethub.af" style="text-align: center;" target="_blank"> Developed by Nethub</a>
                            </div>
                        </div>

                    </div>
                    <!--  -->


				</div>

			</div>
		</main>
	</div>

	</div>

@include('layouts.footer')
</body>

</html>

