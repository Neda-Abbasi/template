@extends('app')
@section('title', 'Clients')

@section('content')
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>
                    تغییر رمز کاربر
                </h4>
                {{-- @if($errors->any())
                    {{ implode('', $errors->all('<div>:message</div>')) }}
                @endif --}}
            </div>
            @include('layouts.component.alert')
            <form class="" action="{{route('profile.update', auth()->user() )}}" method="POST">
                @csrf
                @method('PUT')
   
                <div class="form-row align-items-center">
                    <div class="col-3">
                        <label class="" for="inlineFormInput">رمز فعلی</label>
                        <input type="password" class="form-control " id="inlineFormInput" name="currentPassword">
                        @error('currentPassword')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-3">
                        <label class="" for="inlineFormInput">رمز جدید</label>
                        <input type="password" class="form-control " id="inlineFormInput" name="password">
                        @error('newPassword')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-3">
                        <label class="" for="inlineFormInput">تایید رمز جدید</label>
                        <input type="password" class="form-control " id="inlineFormInput" name="password_confirmation">
                        @error('renewPassword')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    
                    <div class="col-1">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block f-primary text-center"> تغیر رمز</button>
                    </div>
                </div>
                

            </form>
    
            

        </div>



    </div>
</div>
@endsection

@section('pagescript')
    <script src="/js/client/index.js"></script>
@endsection

