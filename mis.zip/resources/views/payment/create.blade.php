@extends('app')
@section('title', 'Staff')

@section('content')
<div class="container-fluid ">

    <!-- content -->
    <!-- breadcrumb -->

    <div class="row m-2 mb-1">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 jumbotron shade pt-1">
            <div class="col-sm-12">
                <h4>
                     
                     @if (isset($payment))
                     {{'پرداخت به کارمند'}}

                     @else
                     {{'پرداخت به کارمند'}}
                     @endif
                </h4>
                {{-- @if($errors->any())
                    {{ implode('', $errors->all('<div>:message</div>')) }}
                @endif --}}
                @php 
                // dd($payment); 
                @endphp
            </div>
            @include('layouts.component.alert')
            <form class="" action="{{isset($payment) ? route('payment.update', $payment): route('payment.store')}}" method="POST" >
                @csrf
                @if(isset($payment))
                    @method('PUT')
                @else
                    @method('POST')
                @endif
                
                <div class="form-row align-items-center">
                    <div class="col-6  col-sm-4">
                        <label class="" for="inlineFormInputGroup">کارمند </label>
                        <select class="form-control " name="staff" id="staff">
                            <option value="">انتخاب نمایید</option>
                            @foreach ($staffs as $staff)
                                <option value="{{$staff->id}}" data-percentage="{{$staff->percentage}}" data-fathername="{{$staff->fathername}}" @if(isset($payment)) @if($staff->id == $payment->staff_id){{'selected'}} @endif @endif>{{$staff->name}} {{$staff->last_name}} </option>    
                            @endforeach
                        </select>    
                        @error('staff')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-4">
                        <label class="" for="fathername">نام پدر</label>
                        <input type="text" class="form-control " readonly id="fathername" name="fathername" value="{{isset($payment) ? $payment->staff->fathername:''}}">
                    </div>
                   
                    <div class="col-4">
                        <label class="" for="inlineFormInputGroup">تاریخ</label>
                        <input type="date" class="form-control " name="pay_date"  value="{{isset($payment) ? $payment->pay_date: old('pay_date')}}">
                        @error('pay_date')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-2">
                        <label class="" for="inlineFormInputGroup">مبلغ</label>
                        <input type="number" step="0.01" class="form-control " name="amount"  value="{{isset($payment) ? $payment->amount: old('amount')}}">
                        @error('amount')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="col-9">
                        <label class="" for="inlineFormInputGroup">تفصیلات</label>
                        <input type="text" class="form-control " name="description"  value="{{isset($payment) ? $payment->description: old('description')}}">
                        @error('description')
                            <span class="alert text-danger">{{$message}}</span>
                        @enderror
                    </div>

                    <div class="col-1">
                        <label class="" for="inlineFormInputGroup"><br></label>
                        <button type="submit" class="btn btn-block {{isset($payment) ?'f-primary':'f-secondary' }} text-center"> {{isset($payment) ?'ویرایش':'ثبت' }}</button>
                    </div>
                </div>
            </form>
        </div>

    </div>
</div>
@endsection

@section('pagescript')
    <script src="{{asset('/js/payment/index.js')}}"></script>
@endsection

