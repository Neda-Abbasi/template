<!DOCTYPE html>
<html lang="en" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

  <title>PDF</title>
  <link href="https://fonts.googleapis.com/css2?family=Amiri&display=swap" rel="stylesheet">
    <style type="text/css">
        body{
            direction: rtl;
            font-family: Amiri, DejaVu Sans, monospace;
            font-size: 36pt;
        }

    .uper {
      margin-top: 40px;
    }
    </style>
</head>
<body>
<div style="position: relative; width:300px;border:1px solid #000;">
  <div class="container">
    <h3>خدمات پولی نت هب</h3>
    <h5>آدرس: گلبهار سنتر منزل اول، دوکان شماره ۲۰</h5>
    <h5>شماره تماس: ۰۷۸۰۱۰۰۶۷۶</h5>

    <p>{!! date('d-m-Y', strtotime($created_at)) !!}</p>
    <h5>{{$hawala}}</h5>
</div>
</div>
</body>
</html>