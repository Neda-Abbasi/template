<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class SarafFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'name' => $this->faker->name(),
            'fathername' => $this->faker->name(),
            'company' => $this->faker->name(),
            'mobile' => '0795010124', 
            'tazkira' => $this->faker->word(), 
            'address' => $this->faker->word(), 
            'status' => '1', 
            'user_id' => 1,
        ];
    }
}
