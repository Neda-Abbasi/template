<?php

namespace Database\Seeders;

use App\Models\client;
use App\Models\Saraf;
use Database\Factories\ClientFactory;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // Client::factory(10)->create();
        // Saraf::factory(10)->create();

        DB::table('users')->insert(
            array(
                'name' => 'admin',
                'email' => 'info@nethub.af',
                'password' => '$2y$10$um26d/X1bU6X7u7tmEn5MOPHIf.dSE3wvWdPR8c7HsZg0TGHFqA2.',
            )
        );
    }
}
