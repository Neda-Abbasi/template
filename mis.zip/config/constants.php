<?php

// return [
	
// 	'OWT_APP' => 'ONLINE WEB TUTOR APPLICATION',
// 	'OWT_KEY' =>'xxxxx-xxxx',
// 	'OWT_SECRET' => 'xxxxxxx-xxxxxx-xxxx'
// ];

return[
'CURRENCIESPAIR' => array(
	'USD' => 'USD',
	'AFN' => 'AFN',
	'PKR' => 'PKR', 
	'EURO' => 'EURO',
	'IRR' => 'IRR',
	'GBP' => 'GBP',
),
'CURRENCIES' => array('USD', 'AFN', 'PKR', 'EURO', 'IRR', 'GBP')
];